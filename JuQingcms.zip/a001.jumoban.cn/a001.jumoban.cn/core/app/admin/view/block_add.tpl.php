<?php include $this->admin_tpl('header');?>
 <div class="position">当前位置：区块编辑</div>

<div class="subnav">

<div class="am-btn-group">
		<a href="<?php echo url('block'); ?>"  class="am-btn am-btn-default am-radius am-text-sm">全部区块</a>
		<?php if($this->menu('block-add')) { ;?>
            <a href="<?php echo url('block/add'); ?>" class="am-btn am-btn-secondary am-radius am-text-sm"><span class="am-icon-plus am-margin-right-sm"></span>添加区块</a>
    	<?php } ?>
        </div> 	<div class="bk10"></div>
		<form action="" method="post">
		<input name="id" type="hidden" value="<?php echo $data['id']; ?>">
		<table width="100%" class="table_form">
		<tr>
			<th width="80">区块名称： </th>
			<td><input class="input-text" style="width: 500px;" type="text" name="data[name]" value="<?php echo $data['name']; ?>" size="40"/>    编辑方式：<select class="select" style="width:100px;" id="type" name="data[type]" onChange="select_type(this.value)">
			<option class="select"  value="0"> ... 请选择方式</option>
			<?php if (is_array($this->type))  foreach ($this->type as $i=>$v) { ?>
			<option value="<?php echo $i; ?>" <?php if ($data['type']==$i) { ?>selected<?php } ?>><?php echo $v; ?></option>
			<?php }  ?>
			</select></td>
		</tr>
		<tr id="text_1" style="display:none">
			<th>区块内容： </th>
			<td><textarea name="data[content_1]" id="data[content]" cols="105" rows="28" style="width: 680px; height: 385px;"><?php echo $data['content']; ?></textarea>
			<br><div class="onShow">区块内容支持HTML标签</div></td>
		</tr>
		<tr id="text_2" style="display:none">
			<th>区块内容： </th>
			<td><?php $field = new Field();  echo $field->file('content_2',$data['content'],array('type'=>'gif,jpg,jpeg,png','preview'=>1,'size'=>20,'buttontxt'=>'上传图片')); ?>
			</td>
		</tr>
		<tr id="text_3" style="display:none;">
			<th>区块内容：</th>
			<td>
			<?php echo $field->editor('content_3', $data['content'], array('system'=>1,'toolbar'=>1)); ?>
			</td>
		</tr>
		<tr>
			<th>&nbsp;</th>
			<td><input class="button" type="submit" name="submit" value="提交" /></td>
		</tr>
		</table>
		</form>
</div>
<script type="text/javascript">
function select_type(id) {
	$("#text_1").hide();
	$("#text_2").hide();
	$("#text_3").hide();
	$("#text_"+id).show();
}
<?php if ($data['type']) { ?>
$("#text_<?php echo $data['type']; ?>").show();
<?php } ?>
</script> 
</body>
</html>
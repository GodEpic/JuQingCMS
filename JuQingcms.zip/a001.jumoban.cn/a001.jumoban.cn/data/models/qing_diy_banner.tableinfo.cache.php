<?php
if (!defined('IN_JUQINGCMS')) exit();
return array (
  'primaryKey' => 'id',
  'fields' => 
  array (
    0 => 'id',
    1 => 'weizhi',
    2 => 'tupian',
    3 => 'lianjie',
  ),
);
<?php
if (!defined('IN_JUQINGCMS')) exit();
return array (
  'primaryKey' => 'id',
  'fields' => 
  array (
    0 => 'id',
    1 => 'sitename',
    2 => 'siteurl',
    3 => 'paixu',
  ),
);
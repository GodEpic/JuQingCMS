<?php
if (!defined('IN_JUQINGCMS')) exit();
return array (
  'primaryKey' => 'userid',
  'fields' => 
  array (
    0 => 'userid',
    1 => 'username',
    2 => 'password',
    3 => 'roleid',
    4 => 'realname',
    5 => 'auth',
    6 => 'list_size',
    7 => 'left_width',
    8 => 'color',
  ),
);
<?php include $this->_include('top.html'); ?>
<script type="text/javascript" src="<?php echo $site_template; ?>style/js/jquery.SuperSlide.2.1.3.js"></script>
</head>
<body>
<?php include $this->_include('header.html'); ?>
<div class="searchBg">
  <div class="search container">
    <div class="keyWord fl"><b>最近更新：</b>
      <ul>
        <?php $return = $this->_listdata("num=3 "); extract($return); if (is_array($return))  foreach ($return as $key=>$qing) { ?>
        <a href="<?php echo $qing[url]; ?>" title="<?php echo $qing[title]; ?>"><?php echo strcut("$qing[title]",20,"…"); ?></a>
        <?php } ?>
      </ul>
    </div>
    <div class="searchBox fr">
      <form action="<?php echo $site_url; ?>index.php" method="Get" onSubmit="return checksearch(this)">
        <input type="hidden"  value="index"  name="c" />
        <input type="hidden"  value="search"  name="a" />
        <input type="text"  name="kw" class="soText"  placeholder="请输入关键字"/>
        <input class="soBtn" type="submit" value="搜索"/>
      </form>
    </div>
  </div>
</div>
<div class="cpbg">
  <div class="cpbox container" id="pro_box">
    <div class="famu fl">
      <h4> <a href="<?php echo $cats[2][url]; ?>"> <img src="<?php echo $site_template; ?>style/images/famutit.png" width="210" height="56" /></a> </h4>
      <div id="pro_tit">
      <ul>
        <?php $return = $this->_category("parentid=2 num=7");  if (is_array($return))  foreach ($return as $key=>$qing) { $allchildids = @explode(',', $qing['allchildids']);    $current = in_array($catid, $allchildids);?>
        <li><a href="<?php echo $qing[url]; ?>">+ <?php echo $qing[catname]; ?></a></li>
        <?php } ?>
      </ul>
      </div>
      <div class="faphone">
        <div class="wenzi">
          <?php $this->block(15);?>
        </div>
        <span class="rexian">客服咨询热线</span> <span class="tel"><?php $this->block(5);?></span> <span class="lx"><a href="<?php echo $cats[7][url]; ?>">联系我们</a></span> </div>
    </div>
    <div class="cplist fr">
      <h4 class="conttit"> <a class="tita" href="<?php echo $cats[2][url]; ?>">新品推荐</a> <span>New Products</span><a class="titmore" href="<?php echo $cats[2][url]; ?>"><img src="<?php echo $site_template; ?>style/images/titmore.png" /></a> </h4>
        <div class="contcont">
          <div id="pro_cont">
          <?php $return = $this->_category("parentid=2 num=7");  if (is_array($return))  foreach ($return as $key=>$qing) { $allchildids = @explode(',', $qing['allchildids']);    $current = in_array($catid, $allchildids);?>
          <ul>
            <?php $return = $this->_listdata("catid=$qing[catid] num=9"); extract($return); if (is_array($return))  foreach ($return as $key=>$qing) { ?>
            <li class='nomr'><a href="<?php echo $qing[url]; ?>" title="<?php echo $qing[title]; ?>"> <img alt="<?php echo $qing[title]; ?>" src="<?php echo image($qing[thumb]); ?>" width="230" height="176" /></a>
              <h5> <a href="<?php echo $qing[url]; ?>" title="<?php echo $qing[title]; ?>"> <?php echo $qing[title]; ?></a></h5>
            </li>
            <?php } ?>
          </ul>
          <?php } ?>
          </div>
        </div>
    </div>
    <div class="clear"> </div>
  </div>
</div>
<div class="box MB10">
  <div class="box_c">
    <div class="box_cl fl">
      <h6><?php $this->block(17);?></h6>
      <span>10年专注于企业建材家具定制！</span></div>
    <div class="box_cr fr"><a href="tencent://message/?uin=<?php $this->block(8);?>&Site=&Menu=yes" target="_blank">咨询客服人员</a></div>
  </div>
</div>
<div style="width:1000px;margin-top:20px;">
  <div class="about_t">
    <div class="more"><a href="<?php echo $cats[18][url]; ?>" target="_blank">+ 了解详情</a> </div>
    <div>
      <h3><?php echo $cats[18][catenname]; ?></h3>
      <h2><?php echo $cats[18][catname]; ?></h2>
    </div>
  </div>
</div>
<div class="jjfabox container">
  <ul class="facont fr">
    <?php $return = $this->_listdata("catid=18 num=6"); extract($return); if (is_array($return))  foreach ($return as $key=>$qing) { ?>
    <li><a href="<?php echo $qing[url]; ?>" title="<?php echo $qing[title]; ?>"> <img alt="<?php echo $qing[title]; ?>" src="<?php echo image($qing[thumb]); ?>" width="318" height="278" /></a>
      <h5> <a href="<?php echo $qing[url]; ?>" title="<?php echo $qing[title]; ?>"> <?php echo $qing[title]; ?></a></h5>
    </li>
    <?php } ?>
  </ul>
  <div class="clear"> </div>
  <div class="case">
    <div class="poxt">
      <h4><a href="<?php echo $cats[17][url]; ?>"><?php echo $cats[17][catname]; ?></a> <span><?php echo $cats[17][catenname]; ?></span></h4>
    </div>
    <div class="ibox7">
      <div id="LeftArr1"></div>
      <div class="ihonor" id="ISL_Cont_1">
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <?php $return = $this->_listdata("catid=17 num=8"); extract($return); if (is_array($return))  foreach ($return as $key=>$qing) { ?>
            <td><a href="<?php echo $qing[url]; ?>"><img src="<?php echo image($qing[thumb]); ?>" alt="<?php echo $qing[title]; ?>" /></a></td>
            <?php } ?>
          </tr>
        </table>
      </div>
      <div id="RightArr1"></div>
    </div>
  </div>
<script language="javascript" type="text/javascript">
var scrollPic_03 = new ScrollPic();
scrollPic_03.scrollContId   = "ISL_Cont_1"; //内容容器ID
scrollPic_03.arrLeftId      = "LeftArr1";//左箭头ID
scrollPic_03.arrRightId     = "RightArr1"; //右箭头ID
scrollPic_03.frameWidth     = 896;//显示框宽度
scrollPic_03.pageWidth      = 224; //翻页宽度
scrollPic_03.speed          = 10; //移动速度(单位毫秒，越小越快)
scrollPic_03.space          = 10; //每次移动像素(单位px，越大越快)
scrollPic_03.autoPlay       = true; //自动播放
scrollPic_03.autoPlayTime   = 3; //自动播放间隔时间(秒)
scrollPic_03.initialize(); //初始化
</script> 
</div>
<div class="hxysbg">
  <div class="hxysbox container">
    <div class="hxystit"> <span>我们的5大核心优势</span>
      <p> 为环保部门提供创新的产品和优质的服务</p>
    </div>
    <ul>
      <li>
        <h5> 行业第一</h5>
        <p> 中国领先的专业环境在线监控系统服务商，油烟监控行业第一。</p>
      </li>
      <li>
        <h5> 技术领先</h5>
        <p> 油烟监控领域首家国家级高新技术企业，拥有20余项知识产权，其中，发明专利4项，遥遥领先于同行。</p>
      </li>
      <li>
        <h5> 莲英精神</h5>
        <p> 独创“莲英精神”—您听不到、看不到、想不到、做不到的，正虹替您听到、看到、想到、做到。</p>
      </li>
      <li>
        <h5> 数字环保</h5>
        <p> 充分利用现有的环境信息资源，统一规划、统一规范、统一建设，为环保部门搭建数字环保综合信息平台。</p>
      </li>
      <li>
        <h5> 量身定制</h5>
        <p> 丰富的项目管理和技术经验，为您量身定制个性化的环保解决方案。</p>
      </li>
    </ul>
  </div>
</div>
<div class="clear"></div>
<div class="index_abt">
  <div class="about">
    <div class="about_t">
      <div class="more"><a href="<?php echo $cats[1][url]; ?>" target="_blank">+ 了解详情</a> </div>
      <div>
        <h3><?php echo $cats[1][catenname]; ?></h3>
        <h2><?php echo $cats[1][catname]; ?></h2>
      </div>
    </div>
    <div class="about_c">
      <div class="about_cl fl"><img src="<?php $this->block(16);?>" /></div>
      <div class="about_cr fr">
        <h3><?php echo $cats[8][catname]; ?></h3>
        <?php $jianjie=$cats[8][content];  $jianjie1 = strip_tags($jianjie);  $jianjie2 = str_replace("&amp;nbsp;","",$jianjie1);  $jianjie3 = str_replace("&amp;nbsp","",$jianjie2); ?>
        <span><?php echo strcut("$jianjie3",450,"…"); ?></span> <a href="<?php echo $cats[8][url]; ?>" target="_blank">了解详情+</a> </div>
    </div>
  </div>
</div>
<div class="dtspan container"> 
  <!--动态-->
  <div class="dtbox fl">
    <h4>
      <a class="cur" href="<?php echo $cats[19][url]; ?>" id="chknew1" onMouseOver="setTabNews('chknew',1,2);"> <?php echo $cats[19][catname]; ?><em><?php echo $cats[19][catenname]; ?></em></a>
      <a href="<?php echo $cats[20][url]; ?>" id="chknew2" onMouseOver="setTabNews('chknew',2,2);"> <?php echo $cats[20][catname]; ?><em><?php echo $cats[20][catenname]; ?></em></a> </h4>
    <div id="con_chknew1" >
      <?php $lmid=19;  $return = $this->_listdata("catid=$lmid num=1"); extract($return); if (is_array($return))  foreach ($return as $key=>$qing) { ?>
      <dl>
        <dt class="fl"><a href="<?php echo $qing[url]; ?>" title="<?php echo $qing[title]; ?>"> <img alt="<?php echo $qing[title]; ?>" src="<?php echo image($qing[thumb]); ?>" width="212" height="150" /></a> </dt>
        <dd>
          <h5> <a href="<?php echo $qing[url]; ?>" title="<?php echo $qing[title]; ?>"> <?php echo $qing[title]; ?></a></h5>
          <?php $miaoshu=$qing[description];  $miaoshu2 = str_replace("&amp;nbsp;","",$miaoshu);  $miaoshu3 = str_replace("&amp;nbsp","",$miaoshu2); ?>
          <p><?php echo strcut("$miaoshu3",160,"…"); ?><a href="<?php echo $qing[url]; ?>" title="<?php echo $qing[title]; ?>"> [详情]</a></p>
        </dd>
      </dl>
      <?php } ?>
      <ul>
        <?php $return = $this->_listdata("catid=$lmid num=1,5"); extract($return); if (is_array($return))  foreach ($return as $key=>$qing) { ?>
        <li><a target="_blank" href="<?php echo $qing[url]; ?>" title="<?php echo $qing[title]; ?>"> <?php echo $qing[title]; ?></a><span><?php echo date('Y-m-d',$qing[time]); ?></span> </li>
        <?php } ?>
      </ul>
    </div>
    <div id="con_chknew2" style='display: none;'>
      <?php $lmid=20;  $return = $this->_listdata("catid=$lmid num=1"); extract($return); if (is_array($return))  foreach ($return as $key=>$qing) { ?>
      <dl>
        <dt class="fl"><a href="<?php echo $qing[url]; ?>" title="<?php echo $qing[title]; ?>"> <img alt="<?php echo $qing[title]; ?>" src="<?php echo image($qing[thumb]); ?>" width="212" height="150" /></a> </dt>
        <dd>
          <h5> <a href="<?php echo $qing[url]; ?>" title="<?php echo $qing[title]; ?>"> <?php echo $qing[title]; ?></a></h5>
          <?php $miaoshu=$qing[description];  $miaoshu2 = str_replace("&amp;nbsp;","",$miaoshu);  $miaoshu3 = str_replace("&amp;nbsp","",$miaoshu2); ?>
          <p><?php echo strcut("$miaoshu3",160,"…"); ?><a href="<?php echo $qing[url]; ?>" title="<?php echo $qing[title]; ?>"> [详情]</a></p>
        </dd>
      </dl>
      <?php } ?>
      <ul>
        <?php $return = $this->_listdata("catid=$lmid num=1,5"); extract($return); if (is_array($return))  foreach ($return as $key=>$qing) { ?>
        <li><a target="_blank" href="<?php echo $qing[url]; ?>" title="<?php echo $qing[title]; ?>"> <?php echo $qing[title]; ?></a><span><?php echo date('Y-m-d',$qing[time]); ?></span> </li>
        <?php } ?>
      </ul>
    </div>
  </div>
<script type="text/javascript">
  function setTabNews(name, cursel, n) {
	  for (i = 1; i <= n; i++) {
		  var menu = document.getElementById(name + i);
		  var con = document.getElementById("con_" + name + i);
		  if (i == cursel) {
			  menu.className = "cur";
			  con.style.display = "block";
		  } else {
			  menu.className = "";
			  con.style.display = "none";
		  }
	  }
  }
</script> 
  <!-- cb_服务支持 -->
  <div class="fwzc fr">
    <h4 class="conttit"><a class="tita">服务支持</a><span>Support</span></h4>
    <div class="fwimg"> <img src="<?php echo $site_template; ?>style/images/fwzcoimg.png" width="232" height="76" /></div>
    <div class="fwphone"> <span> <?php $this->block(5);?></span></div>
    <ul class="m_form" id="leavewordform">
      <form id="testform" onSubmit="return false">
        <li>
          <label> <img src="<?php echo $site_template; ?>style/images/form_ico01.png" /></label>
          <input class="ipttxt" type="text" name="data[xingming]" placeholder="您的姓名（必填）"/>
        </li>
        <li>
          <label> <img src="<?php echo $site_template; ?>style/images/form_ico02.png" /></label>
          <input class="ipttxt" type="text" name="data[dianhua]" placeholder="您的电话（必填）"/>
        </li>
        <li>
          <label> <img src="<?php echo $site_template; ?>style/images/form_ico03.png" /></label>
          <input class="ipttxt" type="text" name="data[youxiang]" placeholder="您的邮箱"/>
        </li>
        <li class="areli">
          <label> <img src="<?php echo $site_template; ?>style/images/form_ico04.png" /></label>
          <textarea class="txtare" name="data[liuyanneirong]" placeholder="留言内容（必填）"></textarea>
        </li>
        <li>
          <input class="btnsubmit" type="submit" id="btnCheck" value=""/>
        </li>
      </form>
    </ul>
  </div>
  <div class="clear"> </div>
</div>
<script type="text/javascript">
$(function () {
	$("#btnCheck").bind("click", function () {
		$.ajax({
			type: 'POST',
			dataType: "json",
			url: "/index.php?c=index&a=form&modelid=3",
			data: $("#testform").serialize(),
			success: function (data) {
				var ts=data.msg;
				alert(ts);
				if(ts.indexOf("成功") > 0 ){
					window.location.reload(true);
				}
			}
		})
	});
	//
	jQuery("#pro_box").slide({titCell:"#pro_tit ul li",mainCell:"#pro_cont",effect:"left",autoPlay:true,vis:1});
});
</script>
<div class="clear"></div>
<div class="yqljbg">
  <div class="yqlj container">
    <h4 class="conttit"> <a class="tita" href="tencent://message/?uin=<?php $this->block(8);?>&Site=&Menu=yes" target="_blank">友情链接</a><span> links</span></h4>
    <p>
    <?php $return = $this->_listdata("table=diy_flink order=paixu_asc"); extract($return); if (is_array($return))  foreach ($return as $key=>$qing) { ?>
    <a href="<?php echo $qing[siteurl]; ?>" target="_blank"><?php echo $qing[sitename]; ?></a>
    <?php } ?>
    </p>
  </div>
</div>
<?php include $this->_include('footer.html'); ?>
<p style="text-align: center;">Powered by <a  target="_blank" href="http://www.juqingcms.com/">JuQingcms</a> 1.0</p></body>
</html>
<?php
if (!defined('IN_JUQINGCMS')) exit();
return array (
  'host' => '127.0.0.1',
  'username' => 'test_juqingcms_',
  'password' => 'zWJkRzBWb5bE8XYz',
  'dbname' => 'test_juqingcms_',
  'prefix' => 'qing_',
  'port' => '3306',
  'charset' => 'utf8',
);
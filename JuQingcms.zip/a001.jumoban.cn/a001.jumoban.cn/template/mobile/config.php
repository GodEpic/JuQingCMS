<?php return array (
  'file_explan' => 
  array (
    'template|mobile|images|' => 
    array (
      'active.png' => '',
      'btn_search.gif' => '',
      'global.js' => '',
      'icon_gotop.png' => '',
      'icon_head.png' => '',
      'inactive.png' => '',
      'load.gif' => '',
      'slide_loader.gif' => '',
      'slide_show.js' => '',
    ),
  ),
);?>
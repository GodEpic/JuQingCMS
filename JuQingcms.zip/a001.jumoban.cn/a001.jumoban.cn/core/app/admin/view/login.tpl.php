 
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="renderer" content="webkit">
<title>登录页面</title>
<link rel="stylesheet" href="../public/css/amazeui.min.css">
<link rel="stylesheet" href="../public/admin/css/layout.css">
<script src="../public/js/jquery.min.js"></script>
<script src="../public/js/amazeui.min.js"></script>
<script src="../public/admin/js/layer.js"></script>
<script src="../public/validator/jquery.validator.min.js?local=zh-CN"></script>
<!--[if lt IE 9]>
<script src="/public/js/html5shiv.js"></script>
<script src="/public/js/respond.min.js"></script>
<![endif]-->
 

</head>

<body  >
  <div class="demo-1">
    <div id="large-header" class="large-header">
      <canvas id="demo-canvas"></canvas>
      <div class="ui-login am-animation-scale-up">
        <div class="logo"><a href="/"><img src="../public/admin/images/logo.gif"></a></div>
        <form id="form_login" method="post">
          <div class="group">
            <input type="text" name="username" value="" placeholder="请输入用户名" class="am-form-field am-radius" data-rule="用户名:required;username;"><em class="am-icon-user am-icon-fw"></em>
          </div>
          <div class="group">
            <input type="password" name="password" value="" placeholder="请输入密码" class="am-form-field am-radius" data-rule="密码:required;password;"><em class="am-icon-lock am-icon-fw"></em>
          </div>
          <div class="group">
            <input type="text" name="code" id="t2" placeholder="请输入验证码" class="am-form-field am-radius" data-rule="验证码:required;"><em class="am-icon-ticket am-icon-fw"></em>
            <img src="../index.php?c=api&a=checkcode&width=85&height=26" title="点击更换验证码">
          </div>
          <div class="group">
            <input type="submit" value="登录" class="am-btn am-btn-primary am-btn-block am-radius">
          </div>
        </form>
        <div id="myContainer"></div>
        <div class="am-text-center am-text-xs am-animation-slide-bottom am-animation-delay-1"> </div>
      </div>
    </div>
  </div>

<script>
$(function(){
  $("img").click(function(){
    var img=$(this).attr("src");
    if(img.indexOf('?')>0)
    {
      $(this).attr("src",img+'&random='+Math.random());
    }
    else
    {
      $(this).attr("src",img.replace(/\?.*$/,'')+'?'+Math.random());
    }
    $("#t2").val("");
  });
    $('#form_login').validator({
    timely:2,
    stopOnError:true,
    focusCleanup:true,
    ignore:':hidden',
    theme:'yellow_right_effect',
    valid:function(form)
    {
      $.AMUI.progress.inc();
      $.ajax({
        type:'post',
        cache:false,
        dataType:'json',
        url:'index.php?c=login',
        data:$(form).serialize(),
        error:function(e){alert(e.responseText);},
        success:function(d)
        {
          $.AMUI.progress.set(1.0);
          if(d.state=='success')
          {
            layer.msg(d.msg);
            setTimeout(function(){location.href='./';},1500);
          }
          else
          {
            layer.msg(d.msg);
            if(d.msg=='请联系juqingcms官网客服授权后使用')
            {
               setTimeout(function(){location.href='http://www.juqingcms.com';},2000);
            }


          }
        }
      })
    }
  });
})
</script>

<script src="../public/admin/js/TweenLite.min.js"></script>
<script src="../public/admin/js/EasePack.min.js"></script>
<script src="../public/admin/js/rAF.js"></script>
<script src="../public/admin/js/demo-1.js"></script>

</body>
</html>


<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>JuQingCms</title>
<link rel="stylesheet" href="../public/css/amazeui.min.css">
<link rel="stylesheet" href="../public/admin/css/layout.css">
<link href="../public/admin/css/skin_<?php echo $this->admin['color']; ?>.css" rel="stylesheet" type="text/css" id="demoCss">
<script src="../public/js/jquery.min.js"></script>
<script src="../public/js/amazeui.min.js"></script>
<script src="../public/admin/js/layer.js"></script>
<script src="../public/validator/jquery.validator.min.js?local=zh-CN"></script>
<script src="../public/admin/js/jquery.sobox.min.js"></script>
<script src="../public/ueditor/third-party/webuploader/webuploader.min.js"></script>
<script src="../public/admin/js/base.js"></script>
<!--[if lt IE 9]>
<script src="/public/js/html5shiv.js"></script>
<script src="/public/js/respond.min.js"></script>
<![endif]-->
</head>
<body>
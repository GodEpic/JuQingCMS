<?php
if (!defined('IN_JUQINGCMS')) exit();
return array (
  'primaryKey' => 'id',
  'fields' => 
  array (
    0 => 'id',
    1 => 'catid',
    2 => 'modelid',
    3 => 'title',
    4 => 'thumb',
    5 => 'keywords',
    6 => 'description',
    7 => 'listorder',
    8 => 'status',
    9 => 'hits',
    10 => 'username',
    11 => 'time',
  ),
);
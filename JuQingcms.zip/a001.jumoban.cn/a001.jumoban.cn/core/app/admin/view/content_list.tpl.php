<?php include $this->admin_tpl('header');?>
<style type="text/css">
.juqingcms-page{
	text-align: center;
	margin-top: 20px;
}
</style>
<div class="position">当前位置：<?php if(empty($catid)) echo '全部内容'; else { echo $this->category_cache[$catid]['catname'];} ?></div>
<div class="subnav">
		<?php if($this->menu('content-add') && !empty($catid)) { ;?>
		<div class="am-btn-group">
            <a href="<?php echo url('content/add',   array('catid'=>$catid)); ?>" class="am-btn am-btn-secondary am-radius am-text-sm"><span class="am-icon-plus am-margin-right-sm"></span>添加内容</a>
        </div>
    	<?php } ?>

		<div class="am-btn-group am-btn-group-sm am-btn-toolbar am-margin-left-xs">
            <a class="am-btn  <?php if (!isset($status)) echo 'am-btn-warning' ; else echo 'am-btn-default'; ?> am-radius" href="<?php echo url('content/index', array('catid'=>$catid)); ?>">全部</a>
            <?php foreach ($this->status_arr  as $key=>$t) { ?>
            <a class="am-btn <?php if (isset($status) && $status==$key) echo 'am-btn-warning'; else echo 'am-btn-default'; ?> am-radius" href="<?php echo url('content/index', array('catid'=>$catid, 'status'=>$key)); ?>"><?php echo $t; ?></a>
            <?php } ?>
        </div>

<form action="" class="am-form am-form-inline am-fr nice-validator n-default" novalidate="novalidate">
                <div class="am-form-group am-form-icon">
            <i class="am-icon-search"></i>
		<input type="hidden"  value="content"  name="c" />
		<input name="catid" type="hidden" value="<?php echo $catid; ?>">
            <input type="text" name="title" class="am-form-field am-input-sm" value="<?php echo $title; ?>" placeholder="请输入关键字">
        </div>
        <input type="submit" value="搜索" class="am-btn am-btn-warning am-radius am-text-sm">
        </form>



		<form action="" method="post" name="myform" id="myform" >
		<input name="status" id="list_form" type="hidden" value="">
		<input name="catid" type="hidden" value="<?php echo $catid; ?>">






<div class="am-panel am-panel-default am-margin-top">
       <div class="am-panel-hd">
           <h3 class="am-panel-title"><?php if(empty($catid)) echo '全部内容'; else { echo $this->category_cache[$catid]['catname'];} ?></h3>
       </div>
 		<table width="100%"  class="am-table am-table-hover">
		<thead class="table-thead">
		<tr>
			<th width="20" align="left"><input id="deletec" type="checkbox" onClick="setC()"></th>
			<th width="70" align="left">排序</th>
			<th width="120" align="left">缩略图</th>
 			<th align="left">标题</th>
			<th align="left">栏目</th>
			<th width="120" align="left">更新时间</th>
			<th width="230" align="left">操作</th>
		</tr>
		</thead>
		<tbody>
		<?php if (is_array($list)) foreach ($list as $t) { ?>
		<tr>
			<td align="left"><input name="batch[]" value="<?php echo $t['id']; ?>" type="checkbox" class="deletec"></td>
			<td align="left"><input type="text" name="listorder[<?php echo $t['id']; ?>]" class="n-valid"  size='1'  value="<?php echo $t['listorder']; ?>"></td>
			<td align="left"><a href="<?php echo url('content/edit',array('id'=>$t['id'])); ?>"><img src="<?php echo image($t['thumb']); ?>" style="width: 80px;max-height: 80px;"></a></td>


 			<td align="left">
			<?php if (is_array($this->status_arr))  foreach ($this->status_arr  as $key=>$r) { ?>
			<?php  if ($t['status']==$key && $key!=1) {?>
			<a href="<?php echo url('content/index', array('catid'=>$catid, 'status'=>$key)); ?>"><font color="#f00">[<?php echo $r; ?>]</font></a>
			<?php }  ?>
			<?php } ?>
			<a href="<?php echo url('content/edit',array('id'=>$t['id'])); ?>"><?php echo $t['title']; ?></a>
			</td>
			<td align="left"><a href="<?php echo url('content/index',array('catid'=>$t['catid'])); ?>"><?php echo $this->category_cache[$t['catid']]['catname']; ?></a></td>

			
			<td align="left"><span style="<?php if (date('Y-m-d', $t['time']) == date('Y-m-d')) { ?>color:#F00<?php } ?>" title="<?php echo date('H:i', $t['time']); ?>"><?php echo date('Y-m-d', $t['time']); ?></span></td>
			
			<td align="left">
			<?php if (get_cache('form_model'))  foreach (get_cache('form_model') as $j) { if ($j['joinid']==$modelid && !empty($catid) && empty($child)) {?>
			<a href="<?php echo url('form/index',array('cid'=>$t['id'], 'modelid'=>$j['modelid'])); ?>"><?php echo $j['modelname']; ?></a> |
			<?php } }  ?>
 			
			<a href="<?php echo $this->view->get_show_url($t); ?>" target="_blank">查看</a> | 
			<a href="<?php echo url('content/edit',array('id'=>$t['id'])); ?>" ><span class="am-icon-edit"></span>编辑</a> | 
			<a href="javascript:confirmurl('<?php echo url('content/del/',array('catid'=>$t['catid'],'id'=>$t['id'])); ?>','确定删除 『 <?php echo $t['title']; ?> 』吗？ ')" ><span class="am-icon-trash"></span>删除</a> 
			</td>
		</tr>
		<?php } ?>
 
		</tbody>
		</table>
                        <div class="border-top am-padding">
                        	<div class="am-u-sm-12 ">

                        		<input type="button"  class="am-btn am-btn-warning am-radius am-text-sm" value="删除" name="delete" onClick="confirm_delete()" >&nbsp;

                        		<input type="submit"  class="am-btn am-btn-warning am-radius am-text-sm" value="排序" name="order" onClick="$('#list_form').val('listorder')">&nbsp;

                        		<?php if (is_array($this->status_arr)) foreach ($this->status_arr  as $key=>$t) { ?>
                        			<input type="submit"  class="am-btn am-btn-warning am-radius am-text-sm" value="设为<?php echo $t; ?>" onClick="$('#list_form').val('<?php echo $key; ?>')">&nbsp;
                        		<?php } ?>
                        		<?php if(empty($child) && !empty($catid)) { ?>
                        			移动至
                        			<select class="select2"  name="movecatid">
                        				<?php echo $category; ?>
                        			</select>
                        			<input type="submit" class="am-btn am-btn-warning am-radius am-text-sm" value="确定移动" name="move" onClick="$('#list_form').val('move')">
                        		<?php } ?>


                        	</div>
                        	<div class="am-u-sm-12 pagelist"><?php echo $pagelist; ?></div>
                <div class="clear"></div>
            </div>
                    </div>

 



		</form>
</div>

</body>
</html>
<?php return array (
  'file_explan' => 
  array (
    'template|' => 
    array (
      'default' => 'PC模板',
      'mobile' => '手机模板',
      'config.php' => '',
      'index.html' => '',
    ),
  ),
);?>
<?php
if (!defined('IN_JUQINGCMS')) exit();
return array (
  'site_name' => '装饰建材家居模板',
  'site_theme' => 'jiancai001',
  'site_mobile' => '1',
  'wap' => '',
  'site_title' => '首页-装饰建材家居模板',
  'site_keywords' => '装饰建材家居模板',
  'site_description' => '装饰建材家居模板',
  'site_status' => '1|正常
2|头条
3|推荐
0|未审核',
  'wxappid' => '',
  'wxappsecret' => '',
  'site_download_image' => '1',
  'site_watermark' => '0',
  'site_watermark_pos' => '5',
  'member_modelid' => '5',
  'qq_login' => '0',
  'appid' => '',
  'appkey' => '',
  'member_register' => '0',
  'member_status' => '1',
  'member_regcode' => '1',
  'member_logincode' => '1',
  'diy_url' => '1',
  'list_url' => '{catdir}/',
  'list_page_url' => '{catdir}/list_{page}.html',
  'show_url' => '{catdir}/{id}.html',
  'show_page_url' => '{catdir}/{id}_{page}.html',
  'rand_code' => 'c685f9ad7557f96ad2704582c627ce26',
);
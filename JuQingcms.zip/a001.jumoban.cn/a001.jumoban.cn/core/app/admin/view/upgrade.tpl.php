
<?php include $this->admin_tpl('header');?>
<div class="position">当前位置：升级提示</div>

<div class="subnav">

<div   style="text-align: center;">
		<br>
		<p style="font-size: 18px">当前版本 v<?php echo JUQINGCMS_RELEASE; ?></p>
 		<p style="font-size: 18px;color: #f20">最新版本 v<?php echo $data['v']; ?></p>
        <a href="<?php echo url('upgrade',array('update' => 1)); ?>" class="am-btn am-btn-warning am-radius  "><span class="am-icon-arrow-up"></span>立即升级到最新版</a>
 		<p style="font-size: 18px;color: #f20">提示：升级前请做好备份网站</p>
         </div> 

	<div class="bk10"></div>
 
</div>
</body>
</html>
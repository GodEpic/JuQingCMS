<?php
if (!defined('IN_JUQINGCMS')) exit();
return array (
  'primaryKey' => 'catid',
  'fields' => 
  array (
    0 => 'catid',
    1 => 'typeid',
    2 => 'modelid',
    3 => 'parentid',
    4 => 'child',
    5 => 'childids',
    6 => 'catname',
    7 => 'image',
    8 => 'content',
    9 => 'seo_title',
    10 => 'seo_keywords',
    11 => 'seo_description',
    12 => 'catdir',
    13 => 'http',
    14 => 'items',
    15 => 'listorder',
    16 => 'ismenu',
    17 => 'ispost',
    18 => 'verify',
    19 => 'islook',
    20 => 'listtpl',
    21 => 'showtpl',
    22 => 'pagetpl',
    23 => 'pagesize',
    24 => 'catenname',
  ),
);
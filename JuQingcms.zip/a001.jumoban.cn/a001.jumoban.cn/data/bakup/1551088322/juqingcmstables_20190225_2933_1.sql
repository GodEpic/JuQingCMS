# juqingcms 
# ----------------------------------------


DROP TABLE IF EXISTS `qing_admin`;
CREATE TABLE `qing_admin` (
  `userid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(32) DEFAULT NULL,
  `roleid` smallint(5) DEFAULT '0',
  `realname` varchar(50) NOT NULL DEFAULT '',
  `auth` text NOT NULL,
  `list_size` smallint(5) NOT NULL,
  `left_width` smallint(5) NOT NULL DEFAULT '150',
  `color` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`userid`),
  KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `qing_admin` VALUES('1','admin','543e77afc5b813812cd27d841a2aa107','1','超级管理员','','10','150','flax');

DROP TABLE IF EXISTS `qing_block`;
CREATE TABLE `qing_block` (
  `id` smallint(8) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) NOT NULL,
  `name` varchar(50) NOT NULL,
  `content` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

INSERT INTO `qing_block` VALUES('1','2','LOGO【电脑版】','/data/upload/image/20181225/1545733811238006.gif');
INSERT INTO `qing_block` VALUES('2','2','LOGO【手机版】','/data/upload/image/20181225/1545733819107766.gif');
INSERT INTO `qing_block` VALUES('3','3','LOGO右侧文字描述【电脑版】','&lt;p&gt;中国CCTV品牌影响力推荐企业品牌&lt;/p&gt;&lt;p&gt;服务至上 ● 诚信诚心&lt;/p&gt;');
INSERT INTO `qing_block` VALUES('4','2','微信二维码','/data/upload/image/20190111/1547185434344496.jpg');
INSERT INTO `qing_block` VALUES('5','1','400电话','400-0000-000');
INSERT INTO `qing_block` VALUES('6','1','手机','13900000000');
INSERT INTO `qing_block` VALUES('7','1','传真','0599-00000000');
INSERT INTO `qing_block` VALUES('8','1','QQ1','123456');
INSERT INTO `qing_block` VALUES('9','1','QQ2','456789');
INSERT INTO `qing_block` VALUES('10','1','QQ3','789123');
INSERT INTO `qing_block` VALUES('11','1','邮箱','123456@qq.com');
INSERT INTO `qing_block` VALUES('12','1','地址','上海市嘉定区XXX办公楼XX室');
INSERT INTO `qing_block` VALUES('13','1','第三方代码','&lt;script&gt;&lt;/script&gt;');
INSERT INTO `qing_block` VALUES('14','2','默认内页banner','/data/upload/image/20181222/1545451240114684.jpg');
INSERT INTO `qing_block` VALUES('15','3','首页产品分类下【文字描述】','&lt;p&gt;精益求精，追求完美品质；&lt;/p&gt;&lt;p&gt;优质高效，引领绿色未来；&lt;/p&gt;&lt;p&gt;持续改进，超越顾客期望。&lt;/p&gt;');
INSERT INTO `qing_block` VALUES('16','2','首页关于我们左侧小图【电脑版】','/data/upload/image/20181222/1545463090217999.jpg');
INSERT INTO `qing_block` VALUES('17','1','内页联系我们【名称】','上海XX信息技术有限公司');

DROP TABLE IF EXISTS `qing_category`;
CREATE TABLE `qing_category` (
  `catid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `typeid` tinyint(1) NOT NULL,
  `modelid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `child` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `childids` varchar(255) NOT NULL,
  `catname` varchar(30) NOT NULL,
  `image` varchar(100) NOT NULL,
  `content` mediumtext NOT NULL,
  `seo_title` varchar(255) NOT NULL,
  `seo_keywords` varchar(255) NOT NULL,
  `seo_description` varchar(255) NOT NULL,
  `catdir` varchar(30) NOT NULL,
  `http` varchar(255) NOT NULL,
  `items` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `listorder` smallint(5) unsigned NOT NULL DEFAULT '0',
  `ismenu` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `ispost` smallint(2) NOT NULL,
  `verify` smallint(2) NOT NULL DEFAULT '0',
  `islook` smallint(2) NOT NULL,
  `listtpl` varchar(50) NOT NULL,
  `showtpl` varchar(50) NOT NULL,
  `pagetpl` varchar(50) NOT NULL,
  `pagesize` smallint(5) NOT NULL,
  `catenname` varchar(255) NOT NULL,
  PRIMARY KEY (`catid`),
  KEY `listorder` (`listorder`,`catid`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;

INSERT INTO `qing_category` VALUES('1','2','0','0','1','8,9,10,11,','关于我们','','','','','','ABOUT','','0','0','1','0','0','0','','','page.html','10','ABOUT US');
INSERT INTO `qing_category` VALUES('2','1','2','0','1','12,13,14,15,16,','产品展示','/data/upload/image/20181222/1545451298125106.jpg','','','','','PRODUCTS','','15','0','1','0','0','0','list_product.html','show_product.html','page.html','12','PRODUCTS');
INSERT INTO `qing_category` VALUES('3','1','1','0','1','17,18,','客户案例','/data/upload/image/20181222/1545451298125106.jpg','','','','','CASES','','10','0','1','0','0','0','list_news_pic.html','show_news.html','page.html','12','CASES');
INSERT INTO `qing_category` VALUES('4','1','1','0','1','19,20,21,','新闻资讯','/data/upload/image/20181222/1545451320636181.jpg','','','','','NEWS','','7','0','1','0','0','0','list_news.html','show_news.html','page.html','20','NEWS');
INSERT INTO `qing_category` VALUES('5','2','0','0','1','22,23,24,','帮助中心','','','','','','HELP','','0','0','1','0','0','0','','','page.html','10','');
INSERT INTO `qing_category` VALUES('6','2','0','0','1','25,26,27,28,29,30,31,32,33,','解决方案','','','','','','PROGRAMME','','0','0','1','0','0','0','','','page.html','10','');
INSERT INTO `qing_category` VALUES('7','2','0','0','1','34,35,','联系我们','','','','','','CONTACT','','0','0','1','0','0','0','','','page.html','10','');
INSERT INTO `qing_category` VALUES('8','2','0','1','0','','公司简介','','&lt;p&gt;创新、超越、与众不同，是我们一如既往的追求.品质、服务、诚信经营，是我们永不变更的承诺。开拓更大的行销渠道，扩大市场占有率，挖掘潜在商机，愿与君共拓国内外PU装饰建材的广阔市场，品牌福建飞客-------您明确的选择!&lt;/p&gt;&lt;p&gt;“行远必自迩、追求无止境”福建飞客装饰建材有限公司公司为建树健康绿色环保的装饰建材事业奉献光热,为锻造品牌福建飞客,永续经营的丰碑而永远向前.&lt;/p&gt;','','','','INTRODUCTION','','0','0','1','0','0','0','','','page.html','10','');
INSERT INTO `qing_category` VALUES('9','2','0','1','0','','发展历程','','','','','','COURSE','','0','0','1','0','0','0','','','page.html','10','');
INSERT INTO `qing_category` VALUES('10','2','0','1','0','','企业文化','','','','','','CULTURE','','0','0','1','0','0','0','','','page.html','10','');
INSERT INTO `qing_category` VALUES('11','2','0','1','0','','企业环境','','','','','','ENVIRONMENT','','0','0','1','0','0','0','','','page.html','10','');
INSERT INTO `qing_category` VALUES('12','1','2','2','0','','产品分类A','','','','','','PROA','','9','0','1','0','0','0','list_product.html','show_product.html','','12','');
INSERT INTO `qing_category` VALUES('13','1','2','2','0','','产品分类B','','','','','','PROB','','3','0','1','0','0','0','list_product.html','show_product.html','','12','');
INSERT INTO `qing_category` VALUES('14','1','2','2','0','','产品分类C','','','','','','PROC','','1','0','1','0','0','0','list_product.html','show_product.html','','12','');
INSERT INTO `qing_category` VALUES('15','1','2','2','0','','产品分类D','','','','','','PROD','','1','0','1','0','0','0','list_product.html','show_product.html','','12','');
INSERT INTO `qing_category` VALUES('16','1','2','2','0','','产品分类E','','','','','','PROE','','1','0','1','0','0','0','list_product.html','show_product.html','','12','');
INSERT INTO `qing_category` VALUES('17','1','1','3','0','','合作伙伴','','','','','','PARTNERS','','5','0','1','0','0','0','list_news_pic.html','show_news.html','','12','Cooperative partner');
INSERT INTO `qing_category` VALUES('18','1','1','3','0','','客户案例','','','','','','CUSTOMER','','5','0','1','0','0','0','list_news_pic.html','show_news.html','','12','Customer case');
INSERT INTO `qing_category` VALUES('19','1','1','4','0','','公司新闻','','','','','','COMPANY_NEWS','','2','0','1','0','0','0','list_news.html','show_news.html','','20','COMPANY NEWS');
INSERT INTO `qing_category` VALUES('20','1','1','4','0','','行业动态','','','','','','INDUSTRY_NEWS','','2','0','1','0','0','0','list_news.html','show_news.html','','20','INDUSTRY NEWS');
INSERT INTO `qing_category` VALUES('21','1','1','4','0','','常见问题','','','','','','COMMON_PROBLEM','','3','0','1','0','0','0','list_news.html','show_news.html','','20','');
INSERT INTO `qing_category` VALUES('22','2','0','5','0','','售后服务','','','','','','SERVICE','','0','0','1','0','0','0','','','page.html','10','');
INSERT INTO `qing_category` VALUES('23','2','0','5','0','','关于配送','','','','','','DELIVERY','','0','0','1','0','0','0','','','page.html','10','');
INSERT INTO `qing_category` VALUES('24','2','0','5','0','','用户指南','','','','','','GUIDE','','0','0','1','0','0','0','','','page.html','10','');
INSERT INTO `qing_category` VALUES('25','2','0','6','0','','制造工业行业','','','','','','MANUFACTURE','','0','0','1','0','0','0','','','page.html','10','');
INSERT INTO `qing_category` VALUES('26','2','0','6','0','','现代农业系统','','&lt;p&gt;老年人是社会的弱势群体，其住宅装饰装修必须与老人家的生理和心理特点相适应，营造舒适优雅、简洁方便、个性突出的生活环境。适合老人的地板是防滑的 ,不反光的,无毒性的,稳固的.&lt;/p&gt;&lt;p&gt;耐磨抗压：超强耐磨、抗冲击、不变形、可重复使用、使用寿命一般为20～30年。&lt;/p&gt;&lt;p&gt;吸音性强：安静是评价居住、办公、疗养环境优劣的基本指标。花岗石、大理石、木地板等隔音效果都不太理想，而PVC胶地板特有的表层和塑胶垫层经无缝处理后，可充分起到吸音的作用。PVC塑胶地板最大能隔绝15db一20db的噪音，解决了噪音的烦恼。&lt;/p&gt;&lt;p&gt;装饰性强：色彩丰富绚丽，可任意拼图，充分发挥自己的创意和想象，完全可满足设计师和不同用户的个性化需求。&lt;/p&gt;&lt;p&gt;脚感舒适：结构致密的表层和高弹垫层经无缝处理后，承托力强，缓冲重压，玻璃器皿掉到地上不易碎裂，保证脚感舒适，接近于地毯，非常适合有老年人和孩子的地方使用。&lt;/p&gt;','','','','AGRICULTURE','','0','0','1','0','0','0','','','page.html','10','');
INSERT INTO `qing_category` VALUES('27','2','0','6','0','','医疗卫生系统','','','','','','MEDICAL','','0','0','1','0','0','0','','','page.html','10','');
INSERT INTO `qing_category` VALUES('28','2','0','6','0','','运动系统行业','','','','','','SPORT','','0','0','1','0','0','0','','','page.html','10','');
INSERT INTO `qing_category` VALUES('29','2','0','6','0','','教育培训系统','','','','','','EDUCATION','','0','0','1','0','0','0','','','page.html','10','');
INSERT INTO `qing_category` VALUES('30','2','0','6','0','','金融保险行业','','','','','','FINANCE','','0','0','1','0','0','0','','','page.html','10','');
INSERT INTO `qing_category` VALUES('31','2','0','6','0','','交通运输系统','','','','','','TRAFFIC','','0','0','1','0','0','0','','','page.html','10','');
INSERT INTO `qing_category` VALUES('32','2','0','6','0','','政府机关单位','','','','','','GOVERNMENT','','0','0','1','0','0','0','','','page.html','10','');
INSERT INTO `qing_category` VALUES('33','2','0','6','0','','餐饮娱乐行业','','','','','','RESTAURANT','','0','0','1','0','0','0','','','page.html','10','');
INSERT INTO `qing_category` VALUES('34','2','0','7','0','','联系方式','','&lt;p&gt;上海XX信息技术有限公司&amp;nbsp;&lt;/p&gt;&lt;p&gt;400电话：400-0000-000&amp;nbsp;&lt;/p&gt;&lt;p&gt;联系手机：13900000000&amp;nbsp;&lt;/p&gt;&lt;p&gt;公司传真：0599-00000000&amp;nbsp;&lt;/p&gt;&lt;p&gt;客服QQ：123456&amp;nbsp;&lt;/p&gt;&lt;p&gt;Email：123456@qq.com&amp;nbsp;&lt;/p&gt;&lt;p&gt;地址：上海市嘉定区XXX办公楼XX室&lt;/p&gt;','','','','CONTACT_INFORMATION','','0','0','1','0','0','0','','','page.html','10','');
INSERT INTO `qing_category` VALUES('35','4','3','7','0','','在线留言','','','','','','ONLINE_MESSAGE','','0','0','1','0','0','0','','','form.html','10','');

DROP TABLE IF EXISTS `qing_content`;
CREATE TABLE `qing_content` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `modelid` smallint(5) NOT NULL,
  `title` varchar(80) NOT NULL DEFAULT '',
  `thumb` varchar(255) NOT NULL DEFAULT '',
  `keywords` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL,
  `listorder` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(2) unsigned NOT NULL DEFAULT '1',
  `hits` smallint(5) unsigned NOT NULL DEFAULT '0',
  `username` char(20) NOT NULL,
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`,`listorder`,`time`),
  KEY `time` (`catid`,`time`),
  KEY `status` (`catid`,`status`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;

INSERT INTO `qing_content` VALUES('1','12','2','塑胶运动地板木纹卷材','/data/upload/image/20181222/1545453437638118.jpg','','一般来说，在灌封过程中,要求环境温度不得高于25℃,否则,所配胶料极易在短时间内硫化拉丝,给灌封操作带来不便。填料预烘温度必须控制在100℃左右,预烘时间为4h左右,使填料内的水分子充分蒸发,否则易造成由','0','1','12','admin','1545453215');
INSERT INTO `qing_content` VALUES('2','12','2','地板卷材复合底2.0mm厚典雅系列','/data/upload/image/20181222/1545453574320715.jpg','','LED户外显示屏灌封胶主要特征:1.良好的流动性，适用于复杂电子配件的灌封，并可使用自动灌胶设备；2.柔软的弹性，抗冲击性好；3.优异的疏水性，使电子产品保持干燥；4.耐热性、耐寒性优秀，户外温度变化大的场合也适','0','1','23','admin','1545453503');
INSERT INTO `qing_content` VALUES('3','12','2','同质透心PVC地板卷材2.0mm厚','/data/upload/image/20181222/1545453622136798.jpg','','产品概述：CODcr在线自动监测仪将重铬酸钾消解方法与先进的计算机技术结合起来，实现了测定过程的全自动化。可广泛地应用于厂矿企业排污口监测、城市污水处理工厂进出口监测、江河湖泊水质监测和污水治理设施控制装','0','1','13','admin','1545453585');
INSERT INTO `qing_content` VALUES('4','12','2','PVC弹性运动地板胶宝石纹卷材','/data/upload/image/20181222/1545453800136023.jpg','','产品概述：CODcr在线自动监测仪将重铬酸钾消解方法与先进的计算机技术结合起来，实现了测定过程的全自动化。可广泛地应用于厂矿企业排污口监测、城市污水处理工厂进出口监测、江河湖泊水质监测和污水治理设施控制装','0','1','35','admin','1545453783');
INSERT INTO `qing_content` VALUES('5','13','2','耐磨PVC地板胶片材3.0mm厚','/data/upload/image/20181222/1545453800136023.jpg','','1、包装规格:50ml/支、100ml/支、300ml/支、2.6L/瓶或按客户要求。2、贮存期:贮存于阴凉干燥处，保存期为12个月。3、说明：以上数据是依据我们广泛实验所得，结果是可靠的。但由于实际应用的多样性，应用条件不是我','0','1','28','admin','1545453909');
INSERT INTO `qing_content` VALUES('6','13','2','PVC地板胶卷材2.0mm','/data/upload/image/20181222/1545454412638978.jpg','','一种半流淌型有机硅胶粘剂，无色透明粘稠液体，绝缘性优、粘接性好，防潮、抗震、耐电晕、抗漏电。胶料对金属和大多数塑料的粘接性良好，固化后具有卓越的抗冷热交变性能。','0','1','20','admin','1545454009');
INSERT INTO `qing_content` VALUES('7','13','2','pvc锁扣木纹地板','/data/upload/image/20181222/1545454119327041.jpg','','DX-905(快干型有机硅密封胶)系列是一种可进行快速粘接的有机硅胶粘剂，绝缘性优、粘接性好，防潮、抗震、耐电晕、抗漏电。胶料对金属和大多数塑料的粘接性良好，固化后具有卓越的抗冷热交变性能(-40~200℃)。','0','1','12','admin','1545454083');
INSERT INTO `qing_content` VALUES('8','14','2','耐磨PVC地板卷材2.0mm厚','/data/upload/image/20181222/1545454319500502.jpg','','本处理剂是依据我们广泛实验所得，结果是可靠的。但由于实际应用的多样性，应用条件不是我们所能控制，所以用户在使用前需进行试验以确认本品是否适用。我公司不担保特定条件下使用我公司产品出现的问题,不承担任何','0','1','28','admin','1545454287');
INSERT INTO `qing_content` VALUES('9','15','2','水晶面PVC地板卷材2.0mm厚','/data/upload/image/20181222/1545454412638978.jpg','','每种材料都有它的优势和应用环境，金属材料是比较早的一种应用方式，但由于材料的物理性能单一，目应用比较少，热辐射是一种比较高端的应用模式，由于应用成本高得不到大力推广，目前应用比较广泛就是非金属材料的，','0','1','15','admin','1545454391');
INSERT INTO `qing_content` VALUES('10','16','2','大理石纹PVC地板片材3.0mm厚','/data/upload/image/20181222/1545454487520856.jpg','','随着如今人们消费水平的提高，单纯的产品质量已经不能成为吸引消费者购买产品的优势了，产品的“服务”已经成为消费者心中权衡的重要指标，塑胶地板企业需要不断的完善服务体系，才能够获得消费者的认可。服务体系的','0','1','16','admin','1545454455');
INSERT INTO `qing_content` VALUES('11','12','2','环保PVC地板卷材3.0mm厚','/data/upload/image/20181222/1545454871547020.jpg','','功能强大，不仅具备现有喷码机的相同功能，更提供多种其它实用功能机身小巧灵便，价格低廉，调节机体高度极为方便，更加适用于流水线生产作业。适用行业：如手机显示屏、饮料瓶盖、食品外包装袋、药盒、塑钢门窗、','0','1','20','admin','1545454846');
INSERT INTO `qing_content` VALUES('12','21','1','物流配送中心选址的影响因素','/data/upload/image/20181222/1545455674116172.jpg','','配送中心所在地区的优惠物流产业政策对物流企业的经济效益将产生重要影响，数量充足和素质较高的劳动力条件也是配送中心选址考虑因素之一。经营不同类型商品的配送中心最好能分别布局在不同地域。如生产型配送中心的','0','1','16','admin','1545454961');
INSERT INTO `qing_content` VALUES('13','21','1','配送中心选址与布局的概念','/data/upload/image/20181222/1545455674116172.jpg','','配送中心选址是以提高物流系统的经济效益和社会效益为目标，根据供货状况、需求分布、运输条件、自然环境等因素，用系统工程的方法，对配送中心的地理位置进行决策的过程，对物流系统的合理化具有决定性的意义。当一','0','1','18','admin','1545454988');
INSERT INTO `qing_content` VALUES('14','21','1','怎么看不到配货信息的联系电话','/data/upload/image/20181222/1545455674116172.jpg','','只有配货通会员才能看到信息的联系方式，还不是易物流网站会员的，立即注册就可以免费查看一天的联系方式，已经是易物流会员的请联系客服人员开通配货会员服务。','0','1','26','admin','1545455028');
INSERT INTO `qing_content` VALUES('15','19','1','家居传统卖场改良销售模式寻突破','/data/upload/image/20181222/1545455674116172.jpg','','如今的家具行业挺有意思，可以用冰火两重天来形容，去到一些企业中，经常会听到同样的抱怨，市场不好，国家又出台调控政策了，经销商不稳定，卖场人流量少……去到另外的一些企业中，则不停地认为市场空间太大，许多','0','1','12','admin','1545455110');
INSERT INTO `qing_content` VALUES('16','20','1','净化水设备一定要定期维护','/data/upload/image/20181222/1545455674116172.jpg','','因为橡胶衬里在水处理设备上应用有10多年了，有些设备寿命面临中晚期，需要修复的设备很多，有些修复用环氧树脂，但是这样的修补不够专业，并且修复不好的环氧树脂层很难清除。离不开您的参与，如果您：1.要出售自己','0','1','17','admin','1545455135');
INSERT INTO `qing_content` VALUES('17','20','1','石英砂过滤器工作原理','/data/upload/image/20181222/1545455674116172.jpg','','因为橡胶衬里在水处理设备上应用有10多年了，有些设备寿命面临中晚期，需要修复的设备很多，有些修复用环氧树脂，但是这样的修补不够专业，并且修复不好的环氧树脂层很难清除。离不开您的参与，如果您：1.要出售自己','0','1','18','admin','1545455174');
INSERT INTO `qing_content` VALUES('18','19','1','安装油烟在线监控系统成效显著','/data/upload/image/20181222/1545455674116172.jpg','','广州越秀区是广州古老的中心城区，经济发展的同时也带动了餐饮业的繁荣。而由此排放的大量餐饮油烟，给城市空气质量造成了不良影响。因此，餐饮单位通过安装油烟在线监控系统，一方面可以预防餐饮油污积累太多而引起','0','1','35','admin','1545455256');
INSERT INTO `qing_content` VALUES('19','17','1','央视CCTV','/data/upload/image/20181222/1545455410432899.jpg','','央视CCTV','0','1','22','admin','1545455402');
INSERT INTO `qing_content` VALUES('20','17','1','一号店商城','/data/upload/image/20181222/1545455438160551.jpg','','一号店商城','0','1','10','admin','1545455425');
INSERT INTO `qing_content` VALUES('21','17','1','海尔商城','/data/upload/image/20181222/1545455452152031.jpg','','海尔商城','0','1','15','admin','1545455446');
INSERT INTO `qing_content` VALUES('22','17','1','太平洋电脑','/data/upload/image/20181222/1545455468863949.jpg','','太平洋电脑','0','1','24','admin','1545455460');
INSERT INTO `qing_content` VALUES('23','17','1','京东商城','/data/upload/image/20181222/1545455481645605.jpg','','京东商城','0','1','23','admin','1545455476');
INSERT INTO `qing_content` VALUES('24','18','1','运动系统行业','/data/upload/image/20181222/1545455571128746.jpg','','很多客户问的最关键的问题还是在与报价，或许手上也有很多公司给寄PVC塑胶地板样品，还是在乎价格，却不会问厚度，是否环保、是否防火、是不是全新料等等问题，也许什么样品从表面上看没有什么区别，PVC塑胶地板一般','0','1','15','admin','1545455559');
INSERT INTO `qing_content` VALUES('25','18','1','商业场所','/data/upload/image/20181222/1545455602256469.jpg','','商业场所要求装饰性和功能性相结合，色彩丰富满足商业装饰需要，优特人表面处理，产品的耐磨、耐压、耐污和易清洁等功能使地面材料承受大人流量并拥有超长使用寿命。在满足装饰需要的同时又能面保养成本。弹性地板在','0','1','21','admin','1545455593');
INSERT INTO `qing_content` VALUES('26','18','1','教育场所','/data/upload/image/20181222/1545455624989214.jpg','','近年来，市民生活水平不断提高，从化市城区餐饮业也开始不断兴旺起来。餐饮业快速发展一方面繁荣了市场，丰富了市民生活，但由于这些中小餐馆大多分布于大街小巷，有的甚至就在居民楼底下，油烟扰民问题日益突出，向','0','1','17','admin','1545455618');
INSERT INTO `qing_content` VALUES('27','18','1','医院病房及走道','/data/upload/image/20181222/1545455654857193.jpg','','城市生活质量的提高和经济的快速发展，餐饮业也随之繁荣。很多餐馆深入社区，油烟废气的污染日益加剧。餐饮业油烟废气正和工业废气、机动车尾气一起，被视为大气的三大“污染杀手”。南海的居民区多年来已经形成了大','0','1','27','admin','1545455644');
INSERT INTO `qing_content` VALUES('28','18','1','医院手术室地面','/data/upload/image/20181222/1545455674116172.jpg','','随着城市生活质量的提高和经济的快速发展，餐饮业也随之繁荣。很多餐馆深入社区，油烟废气的污染日益加剧。餐饮业油烟废气正和工业废气、机动车尾气一起，被视为大气的三大“污染杀手”。广州天河区现有大大小小餐饮','0','1','32','admin','1545455666');
INSERT INTO `qing_content` VALUES('29','12','2','演示pvc锁扣木纹地板','/data/upload/image/20181222/1545454119327041.jpg','','DX-905(快干型有机硅密封胶)系列是一种可进行快速粘接的有机硅胶粘剂，绝缘性优、粘接性好，防潮、抗震、耐电晕、抗漏电。胶料对金属和大多数塑料的粘接性良好，固化后具有卓越的抗冷热交变性能(-40~200℃)。','0','1','13','admin','1545821574');
INSERT INTO `qing_content` VALUES('30','12','2','产品测试2','/data/upload/image/20181222/1545454119934090.jpg','','产品概述：CODcr在线自动监测仪将重铬酸钾消解方法与先进的计算机技术结合起来，实现了测定过程的全自动化。可广泛地应用于厂矿企业排污口监测、城市污水处理工厂进出口监测、江河湖泊水质监测和污水治理设施控制装','0','1','15','admin','1545821607');
INSERT INTO `qing_content` VALUES('31','12','2','测试产品','/data/upload/image/20181222/1545453800956381.jpg','','DX-905(快干型有机硅密封胶)系列是一种可进行快速粘接的有机硅胶粘剂，绝缘性优、粘接性好，防潮、抗震、耐电晕、抗漏电。胶料对金属和大多数塑料的粘接性良好，固化后具有卓越的抗冷热交变性能(-40~200℃)。','0','1','18','admin','1545821675');
INSERT INTO `qing_content` VALUES('32','12','2','还是测试产品','/data/upload/image/20181222/1545454119762953.jpg','','DX-905(快干型有机硅密封胶)系列是一种可进行快速粘接的有机硅胶粘剂，绝缘性优、粘接性好，防潮、抗震、耐电晕、抗漏电。胶料对金属和大多数塑料的粘接性良好，固化后具有卓越的抗冷热交变性能(-40~200℃)。','0','1','19','admin','1545821732');

DROP TABLE IF EXISTS `qing_content_news`;
CREATE TABLE `qing_content_news` (
  `id` mediumint(8) NOT NULL,
  `catid` smallint(5) NOT NULL,
  `content` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `qing_content_news` VALUES('12','21','&lt;p&gt;配送中心所在地区的优惠物流产业政策对物流企业的经济效益将产生重要影响，数量充足和素质较高的劳动力条件也是配送中心选址考虑因素之一。经营不同类型商品的配送中心最好能分别布局在不同地域。如生产型配送中心的选址应与产业结构、产品结构、工业布局等紧密结合进行考虑。物流费用是配送中心选址的重要考虑因素之一。大多数配送中心选择接近物流服务需求地，例如接近大型工业、商业区，以便缩短运距、降低运费等物流费用。&lt;/p&gt;');
INSERT INTO `qing_content_news` VALUES('13','21','&lt;p&gt;配送中心选址是以提高物流系统的经济效益和社会效益为目标，根据供货状况、需求分布、运输条件、自然环境等因素，用系统工程的方法，对配送中心的地理位置进行决策的过程，对物流系统的合理化具有决定性的意义。&lt;/p&gt;&lt;p&gt;当一个物流系统中需要设置多个配送中心，这时不仅要确定配送中心的位置，而且还要对配送中心的数量、规模、服务范围等进行决策，建立一个服务好、效率高、费用低的物流网络系统。对此常称为网点布局。&lt;/p&gt;');
INSERT INTO `qing_content_news` VALUES('14','21','&lt;p&gt;只有配货通会员才能看到信息的联系方式，还不是易物流网站会员的，立即注册就可以免费查看一天的联系方式，已经是易物流会员的请联系客服人员开通配货会员服务。&lt;/p&gt;');
INSERT INTO `qing_content_news` VALUES('15','19','&lt;p&gt;如今的家具行业挺有意思，可以用冰火两重天来形容，去到一些企业中，经常会听到同样的抱怨，市场不好，国家又出台调控政策了，经销商不稳定，卖场人流量少……去到另外的一些企业中，则不停地认为市场空间太大，许多空白点都等待开发，订单忙不过来，为企业的厂能跟不上销售速度而着急……&lt;/p&gt;&lt;p&gt;这样两种截然不同的“抱怨”听多了，让我开始总结，是哪些企业总是沉迷于抱怨之中，哪些企业又忙得不可开交，无暇抱怨。经过一归纳，发现抱怨的企业定位总是模糊的，前几年还见他们在生产板式家具，这几年又在跟风实木家具;企业的市场也是固定的，除了开店就是开店，坐商的姿势总是一成不变;另一个惊人的相似点，就是企业对于自己的定位都仿佛众口一词“生产中高端家具”。有行业人士就分析，这种行业里普遍的“中高端”现象就在于他们“上不去”，也“下不来”，产品档次和企业规模很难往高端上靠，可是将自己定位为低端家具又心有不甘，于是“中高端”成为一种普遍现象。反而在高端家具的生产领域，由于其门槛较高，不容易被同行模仿与跟风，同时受到宏观调控的影响较小，在这两年中异军突起，俨然成为了一批“主力军”，在大势一片低迷的时候来了一次完美的“逆袭”。&lt;/p&gt;');
INSERT INTO `qing_content_news` VALUES('16','20','&lt;p&gt;因为橡胶衬里在水处理设备上应用有10多年了，有些设备寿命面临中晚期，需要修复的设备很多，有些修复用环氧树脂，但是这样的修补不够专业，并且修复不好的环氧树脂层很难清除。&lt;/p&gt;&lt;p&gt;离不开您的参与，如果您：&lt;/p&gt;&lt;p&gt;1.要出售自己的得意模板、插件、教程？欢迎您来这里交易，找到需要她、欣赏她的人。&lt;/p&gt;&lt;p&gt;2.苦苦寻觅某套模板、迫切希望得到设计帮助？这里或许能很快解决您的问题。&lt;/p&gt;&lt;p&gt;3.想找个网络模板收藏夹存放自己喜爱的模板？ 这里就是您的选择。&lt;/p&gt;&lt;p&gt;4.想结交更多热爱模板、插件的朋友？那就快来展示您的作品，寻找志趣相投的朋友吧。&lt;/p&gt;');
INSERT INTO `qing_content_news` VALUES('17','20','&lt;p&gt;因为橡胶衬里在水处理设备上应用有10多年了，有些设备寿命面临中晚期，需要修复的设备很多，有些修复用环氧树脂，但是这样的修补不够专业，并且修复不好的环氧树脂层很难清除。&lt;/p&gt;&lt;p&gt;离不开您的参与，如果您：&lt;/p&gt;&lt;p&gt;1.要出售自己的得意模板、插件、教程？欢迎您来这里交易，找到需要她、欣赏她的人。&lt;/p&gt;&lt;p&gt;2.苦苦寻觅某套模板、迫切希望得到设计帮助？这里或许能很快解决您的问题。&lt;/p&gt;&lt;p&gt;3.想找个网络模板收藏夹存放自己喜爱的模板？ 这里就是您的选择。&lt;/p&gt;&lt;p&gt;4.想结交更多热爱模板、插件的朋友？那就快来展示您的作品，寻找志趣相投的朋友吧。&lt;/p&gt;');
INSERT INTO `qing_content_news` VALUES('18','19','&lt;p&gt;广州越秀区是广州古老的中心城区，经济发展的同时也带动了餐饮业的繁荣。而由此排放的大量餐饮油烟，给城市空气质量造成了不良影响。因此，餐饮单位通过安装油烟在线监控系统，一方面可以预防餐饮油污积累太多而引起的火灾隐患；另一方面，使得油烟得到有效处理，为生态文明城市的建设提供了有力的保障。&lt;/p&gt;&lt;p&gt;前不久，从广州越秀区环保局了解到，越秀区目前有1900多家餐饮单位，其中大型的（100个餐位以上）餐饮单位全都安装了油烟在线监控系统，环保局通过监控系统实时跟踪餐饮单位的油烟排放情况。&lt;/p&gt;&lt;p&gt;目前全区累计安装的油烟在线监控设备有1155台，监控餐饮单位1086家，大型的餐饮单位全部安装油烟在线监控系统，超过六成的餐饮单位安装了监控系统。越秀区的油烟在线监控系统总数约占整个广州市的61%。&lt;/p&gt;&lt;p&gt;“哪家餐饮企业未正常开启油烟净化设备，导致油烟排放超标，我们第一时间就能发现并及时制止”。越秀区环保局相关负责人介绍，油烟在线监控系统实时监视着油烟净化器的运行情况。当大厨炒菜时，系统界面清晰地显示出油烟的实时排放情况，所采集的数据通过无线网络传送到环保部门的监控平台上。&lt;/p&gt;');
INSERT INTO `qing_content_news` VALUES('19','17','&lt;p&gt;央视CCTV&lt;/p&gt;');
INSERT INTO `qing_content_news` VALUES('20','17','&lt;p&gt;一号店商城&lt;/p&gt;');
INSERT INTO `qing_content_news` VALUES('21','17','&lt;p&gt;海尔商城&lt;/p&gt;');
INSERT INTO `qing_content_news` VALUES('22','17','&lt;p&gt;太平洋电脑&lt;/p&gt;');
INSERT INTO `qing_content_news` VALUES('23','17','&lt;p&gt;京东商城&lt;/p&gt;');
INSERT INTO `qing_content_news` VALUES('24','18','&lt;p&gt;很多客户问的最关键的问题还是在与报价，或许手上也有很多公司给寄PVC塑胶地板样品，还是在乎价格，却不会问厚度，是否环保、是否防火、是不是全新料等等问题，也许什么样品从表面上看没有什么区别，PVC塑胶地板一般是由4~5层结构叠压而成，一般有耐磨层(含UV处理)、印花膜层、玻璃纤维层、弹性发泡层、基层；&lt;/p&gt;&lt;p&gt;但是唯独结构上不一样，价格却相差甚远，作为客户本身来说并不太了解或者清楚什么是耐磨层、UV，玻璃纤维层；如果细心的客户就会发现，拿着我们的样品和别人的样品仔细对比及实验，我们的，要比他们的不容易变形，耐污能力更强，更耐磨；可以经过多方面对比一下的！所以还是用句行业话语说：不怕货比货，就怕不识货！&lt;/p&gt;');
INSERT INTO `qing_content_news` VALUES('25','18','&lt;p&gt;商业场所要求装饰性和功能性相结合，色彩丰富满足商业装饰需要，优特人表面处理，产品的耐磨、耐压、耐污和易清洁等功能使地面材料承受大人流量并拥有超长使用寿命。在满足装饰需要的同时又能面保养成本。弹性地板在商业领域是全新的、灵活的地面材料。&lt;/p&gt;&lt;p&gt;保养:由于PVC地板具有表面不渗透的性能，泥土和尘垢能从地板的表层彻底清除。用抹布及好的中型洗涤剂来清洁地面，接着用清水冲洗。微脏的地面右以用湿拖把擦，但也应该定期用抹布擦。严重脏或带黑点可以用地面清洁机器来清洁，在任何擦或清除操作之后，必须用清水冲洗以清除所有残余的清洁剂。表面强化处理技术有助于简化清洁养护过程。终生无需打蜡上光，从而大量减少水、能源和化学品的使用，有益于环镜保护。&lt;/p&gt;');
INSERT INTO `qing_content_news` VALUES('26','18','&lt;p&gt;近年来，市民生活水平不断提高，从化市城区餐饮业也开始不断兴旺起来。餐饮业快速发展一方面繁荣了市场，丰富了市民生活，但由于这些中小餐馆大多分布于大街小巷，有的甚至就在居民楼底下，油烟扰民问题日益突出，向环保局投诉的问题也越来越多。为有效解决群众关心、关注的热点、难点问题，确保良好的城市人居环境，环保局决定大规模集中治理城区范围内所有未采取相关油烟净化措施的餐饮企业及非经营性单位食堂。按照《饮食行业油烟污染试点整治工作实施细则》的要求，正虹公司配合环保局对从化市大范围内餐饮企业实施装油烟在线监控系统。&lt;/p&gt;');
INSERT INTO `qing_content_news` VALUES('27','18','&lt;p&gt;城市生活质量的提高和经济的快速发展，餐饮业也随之繁荣。很多餐馆深入社区，油烟废气的污染日益加剧。餐饮业油烟废气正和工业废气、机动车尾气一起，被视为大气的三大“污染杀手”。南海的居民区多年来已经形成了大量的饭店和餐馆，其中一些饭店没有落实油烟处理措施，一是部分饮食服务企业未按要求安装油烟净化装置；二是部分饮食服务企业虽已安装油烟净化装置但运行不正常，有的擅自拆卸、停运设施，有的不按要求定期清洗维护，有的以排抽风设施替代净化装置等。 最终油烟污染严重影响小区居民生活。根据《中华人民共和国大气污染防治法》规定:城市饮食服务业的经营者,必须遵守国务院有关饮食服务业环境保护管理的规定，采取措施，防治油烟对居住环境的污染。&lt;/p&gt;');
INSERT INTO `qing_content_news` VALUES('28','18','&lt;p&gt;随着城市生活质量的提高和经济的快速发展，餐饮业也随之繁荣。很多餐馆深入社区，油烟废气的污染日益加剧。餐饮业油烟废气正和工业废气、机动车尾气一起，被视为大气的三大“污染杀手”。广州天河区现有大大小小餐饮店一万多家，油烟扰民成了环境投诉的热点问题。2009年，天河区污染投诉信访案件中60%是油烟污染投诉，为减少油烟扰民问题，提高环保部门检查效率，天河区环保局积极建设油烟在线监控系统。&lt;/p&gt;');

DROP TABLE IF EXISTS `qing_content_product`;
CREATE TABLE `qing_content_product` (
  `id` mediumint(8) NOT NULL,
  `catid` smallint(5) NOT NULL,
  `content` mediumtext NOT NULL,
  `yuanjia` varchar(255) NOT NULL,
  `xianjia` varchar(255) NOT NULL,
  `xinghao` varchar(255) NOT NULL,
  `guige` varchar(255) NOT NULL,
  `zutu` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `qing_content_product` VALUES('1','12','&lt;p&gt;一般来说，在灌封过程中, 要求环境温度不得高于25℃, 否则, 所配胶料极易在短时间内硫化拉丝, 给灌封操作带来不便。填料预烘温度必须控制在100 ℃左右, 预烘时间为4 h左右, 使填料内的水分子充分蒸发, 否则易造成由于水分子的残存, 从而造成绝缘材料的表面导电率增加,体积电阻率降低, 介质损耗增加, 导致零部件电器短路、漏电或击穿等问题。&lt;/p&gt;&lt;p&gt;若是灌封印刷板，则需先将印制板清洗后，才可以进行灌封, 再预烘驱潮, 根据印制板组装件所能允许的温度, 确定预烘驱潮的温度和时间, 通常可选用以下的温度：预烘温度：80℃，需要2h;预烘温度：70℃，需要3h;预烘温度：60℃，需要4h;预烘温度：50℃，需要6h。&lt;/p&gt;','88.00','55.00','52HH','99*55','a:2:{s:7:\"fileurl\";a:3:{i:0;s:48:\"/data/upload/image/20181222/1545453437580412.jpg\";i:1;s:48:\"/data/upload/image/20181222/1545453437638118.jpg\";i:2;s:48:\"/data/upload/image/20181222/1545453437815452.jpg\";}s:8:\"filename\";a:3:{i:0;s:5:\"1.jpg\";i:1;s:5:\"2.jpg\";i:2;s:5:\"3.jpg\";}}');
INSERT INTO `qing_content_product` VALUES('2','12','&lt;p&gt;LED户外显示屏灌封胶主要特征:&lt;/p&gt;&lt;p&gt;1.良好的流动性，适用于复杂电子配件的灌封，并可使用自动灌胶设备；&lt;/p&gt;&lt;p&gt;2.柔软的弹性，抗冲击性好；&lt;/p&gt;&lt;p&gt;3.优异的疏水性，使电子产品保持干燥；&lt;/p&gt;&lt;p&gt;4.耐热性、耐寒性优秀，户外温度变化大的场合也适合；&lt;/p&gt;&lt;p&gt;5.缩合型，脱出的乙醇分子对元器件无腐蚀；&lt;/p&gt;&lt;p&gt;6.LED户外显示屏灌封胶无须使用其它的底漆，对PC、ABS等外壳黏附，但对LED等灯面环氧材料不附着；&lt;/p&gt;&lt;p&gt;7.符合ROHS指令要求。&lt;/p&gt;','88.00','55.00','52HH','99*55','a:2:{s:7:\"fileurl\";a:2:{i:0;s:48:\"/data/upload/image/20181222/1545453574136440.jpg\";i:1;s:48:\"/data/upload/image/20181222/1545453574320715.jpg\";}s:8:\"filename\";a:2:{i:0;s:5:\"1.jpg\";i:1;s:5:\"2.jpg\";}}');
INSERT INTO `qing_content_product` VALUES('3','12','&lt;p&gt;产品概述：CODcr在线自动监测仪将重铬酸钾消解方法与先进的计算机技术结合起来，实现了测定过程的全自动化。可广泛地应用于厂矿企业排污口监测、城市污水处理工厂进出口监测、江河湖泊水质监测和污水治理设施控制装置之中。&lt;/p&gt;&lt;p&gt;特点：&lt;/p&gt;&lt;p&gt;·本仪器是国标（GB11914-89）规定方法的自动化装置，与手动分析具有很好的相关性。&lt;/p&gt;&lt;p&gt;·本仪器已通过中国环境产业协会认证，检测数据具有法定效力。&lt;/p&gt;&lt;p&gt;·本仪器具有很宽的量程范围，并可在一定范围内实现不同量程之间的自动切换。&lt;/p&gt;&lt;p&gt;·本仪器具有强的抗氯离子干扰能力，l可直接检测氯离子含量达到10000mg/L的水样。&lt;/p&gt;&lt;p&gt;·新颖的电热设计，确保高的氧化率和寿命。&lt;/p&gt;&lt;p&gt;·断电保护设计确保仪器不受损坏和数据记录永不丢失。&lt;/p&gt;&lt;p&gt;·齐全的接口设计和配套软件，便于仪器与流量计、控制系统和中央监控计算机连接，并可接受遥控指令。&lt;/p&gt;&lt;p&gt;·故障自诊断智能设计，使仪器管理和维护十分方便。&lt;/p&gt;&lt;p&gt;·采样方式可设定为定时采样，也可以设定为等比例采样。&lt;/p&gt;&lt;p&gt;·本仪器具有较强的可扩展性，可最多设置四个采样点的水质分析，方便污水处理的流程控制。产品出厂时配备可在两个采样口采样的功能模块，如果需要测试更多的采样点（最大四个）则需要扩展功能模块。&lt;/p&gt;','88.00','55.00','52HH','99*55','a:2:{s:7:\"fileurl\";a:2:{i:0;s:48:\"/data/upload/image/20181222/1545453622136798.jpg\";i:1;s:48:\"/data/upload/image/20181222/1545453622936371.jpg\";}s:8:\"filename\";a:2:{i:0;s:5:\"1.jpg\";i:1;s:5:\"2.jpg\";}}');
INSERT INTO `qing_content_product` VALUES('4','12','&lt;p&gt;产品概述：CODcr在线自动监测仪将重铬酸钾消解方法与先进的计算机技术结合起来，实现了测定过程的全自动化。可广泛地应用于厂矿企业排污口监测、城市污水处理工厂进出口监测、江河湖泊水质监测和污水治理设施控制装置之中。&lt;/p&gt;&lt;p&gt;特点：&lt;/p&gt;&lt;p&gt;·本仪器是国标（GB11914-89）规定方法的自动化装置，与手动分析具有很好的相关性。&lt;/p&gt;&lt;p&gt;·本仪器已通过中国环境产业协会认证，检测数据具有法定效力。&lt;/p&gt;&lt;p&gt;·本仪器具有很宽的量程范围，并可在一定范围内实现不同量程之间的自动切换。&lt;/p&gt;&lt;p&gt;·本仪器具有强的抗氯离子干扰能力，l可直接检测氯离子含量达到10000mg/L的水样。&lt;/p&gt;&lt;p&gt;·新颖的电热设计，确保高的氧化率和寿命。&lt;/p&gt;&lt;p&gt;·断电保护设计确保仪器不受损坏和数据记录永不丢失。&lt;/p&gt;&lt;p&gt;·齐全的接口设计和配套软件，便于仪器与流量计、控制系统和中央监控计算机连接，并可接受遥控指令。&lt;/p&gt;&lt;p&gt;·故障自诊断智能设计，使仪器管理和维护十分方便。&lt;/p&gt;&lt;p&gt;·采样方式可设定为定时采样，也可以设定为等比例采样。&lt;/p&gt;&lt;p&gt;·本仪器具有较强的可扩展性，可最多设置四个采样点的水质分析，方便污水处理的流程控制。产品出厂时配备可在两个采样口采样的功能模块，如果需要测试更多的采样点（最大四个）则需要扩展功能模块。&lt;/p&gt;','88.00','55.00','52HH','99*55','a:2:{s:7:\"fileurl\";a:3:{i:0;s:48:\"/data/upload/image/20181222/1545453800956381.jpg\";i:1;s:48:\"/data/upload/image/20181222/1545453800977509.jpg\";i:2;s:48:\"/data/upload/image/20181222/1545453800136023.jpg\";}s:8:\"filename\";a:3:{i:0;s:5:\"1.jpg\";i:1;s:5:\"2.jpg\";i:2;s:5:\"3.jpg\";}}');
INSERT INTO `qing_content_product` VALUES('5','13','&lt;p&gt;1、包装规格:50ml/支、100ml/支、300ml/支、2.6L/瓶或按客户要求。&lt;/p&gt;&lt;p&gt;2、贮存期:贮存于阴凉干燥处，保存期为12个月。&lt;/p&gt;&lt;p&gt;3、说明：以上数据是依据我们广泛实验所得，结果是可靠的。但由于实际应用的多样性，应用条件不是我们所能控制，所以用户在使用前需进行试验以确认本品是否适用。我公司不担保特定条件下使用我公司产品出现的问题,不承担任何直接、间接或意外损失的责任。用户在使用过程中遇到什么问题,可以和我公司技术服务部联系,我们将竭力为您提供尽可能的帮助。&lt;/p&gt;','88.00','55.00','52HH','99*55','a:2:{s:7:\"fileurl\";a:2:{i:0;s:48:\"/data/upload/image/20181222/1545453927130825.jpg\";i:1;s:48:\"/data/upload/image/20181222/1545453927108947.jpg\";}s:8:\"filename\";a:2:{i:0;s:5:\"2.jpg\";i:1;s:5:\"1.jpg\";}}');
INSERT INTO `qing_content_product` VALUES('6','13','&lt;p&gt;一种半流淌型有机硅胶粘剂，无色透明粘稠液体，绝缘性优、粘接性好，防潮、抗震、耐电晕、抗漏电。胶料对金属和大多数塑料的粘接性良好，固化后具有卓越的抗冷热交变性能。&lt;/p&gt;','88.00','55.00','52HH','99*55','a:2:{s:7:\"fileurl\";a:2:{i:0;s:48:\"/data/upload/image/20181222/1545454063136169.jpg\";i:1;s:48:\"/data/upload/image/20181222/1545454068117644.jpg\";}s:8:\"filename\";a:2:{i:0;s:5:\"1.jpg\";i:1;s:5:\"2.jpg\";}}');
INSERT INTO `qing_content_product` VALUES('7','13','&lt;p&gt;DX-905 (快干型有机硅密封胶) 系列是一种可进行快速粘接的有机硅胶粘剂，绝缘性优、粘接性好，防潮、抗震、耐电晕、抗漏电。胶料对金属和大多数塑料的粘接性良好，固化后具有卓越的抗冷热交变性能(-40~200℃)。&lt;/p&gt;','88.00','55.00','52HH','99*55','a:2:{s:7:\"fileurl\";a:3:{i:0;s:48:\"/data/upload/image/20181222/1545454119327041.jpg\";i:1;s:48:\"/data/upload/image/20181222/1545454119934090.jpg\";i:2;s:48:\"/data/upload/image/20181222/1545454119762953.jpg\";}s:8:\"filename\";a:3:{i:0;s:5:\"1.jpg\";i:1;s:5:\"2.jpg\";i:2;s:5:\"3.jpg\";}}');
INSERT INTO `qing_content_product` VALUES('8','14','&lt;p&gt;本处理剂是依据我们广泛实验所得，结果是可靠的。但由于实际应用的多样性，应用条件不是我们所能控制，所以用户在使用前需进行试验以确认本品是否适用。我公司不担保特定条件下使用我公司产品出现的问题,不承担任何直接、间接或意外损失的责任。用户在使用过程中遇到什么问题,可以和我公司技术服务部联系,我们将竭力为您提供尽可能的帮助。&lt;/p&gt;','88.00','55.00','52HH','99*55','a:2:{s:7:\"fileurl\";a:2:{i:0;s:48:\"/data/upload/image/20181222/1545454319500502.jpg\";i:1;s:48:\"/data/upload/image/20181222/1545454319271659.jpg\";}s:8:\"filename\";a:2:{i:0;s:5:\"2.jpg\";i:1;s:5:\"1.jpg\";}}');
INSERT INTO `qing_content_product` VALUES('9','15','&lt;p&gt;每种材料都有它的优势和应用环境，金属材料是比较早的一种应用方式，但由于材料的物理性能单一，目应用比较少，热辐射是一种比较高端的应用模式，由于应用成本高得不到大力推广，目前应用比较广泛就是非金属材料的，不仅应用成本低而性能也非常好地解决的了各行各业的问题。&lt;/p&gt;&lt;p&gt;下面小编就以多力仕导热材料来为大家说解一下&lt;/p&gt;&lt;p&gt;导热材料基本上都是有机硅胶和环氧树脂制作而成的，这两种材料都属于非金属材料，在没有凝固时都是液态的，这些就有很好的解决了导热的形状问题，多力仕导热材料的作用是增加热传导和导热面积，形成良好的冷却效率。 有良好的热传导后，可能并不需要太多的冷却风扇这样的散热器，还可节省空间和成本。 电子设备不断的把更多更强大的功能集成到一个面板上， 温度控制已成为非常重要的设计挑战之一，架构紧缩，操作空间越来越小，那么选择合适的导热材料， 有效地排出更多的发电机组产生的热量就显得更加重要。&lt;/p&gt;','88.00','55.00','52HH','99*55','a:2:{s:7:\"fileurl\";a:2:{i:0;s:48:\"/data/upload/image/20181222/1545454412638978.jpg\";i:1;s:48:\"/data/upload/image/20181222/1545454412122937.jpg\";}s:8:\"filename\";a:2:{i:0;s:5:\"2.jpg\";i:1;s:5:\"1.jpg\";}}');
INSERT INTO `qing_content_product` VALUES('10','16','&lt;p&gt;随着如今人们消费水平的提高，单纯的产品质量已经不能成为吸引消费者购买产品的优势了，产品的“服务”已经成为消费者心中权衡的重要指标，塑胶地板企业需要不断的完善服务体系，才能够获得消费者的认可。&lt;/p&gt;&lt;p&gt;服务体系的建设分为售前和售后两方面，目前很多的塑胶地板企业更多的都局限在加强售中与售后的服务体系方面而忽略了售前服务的重要性，事实上售前服务是地板企业在市场抢占先机的重要环节万万忽视。&lt;/p&gt;&lt;p&gt;塑胶地板企业通过做好市场调查，及时掌握产品变动信息；介绍产品知识，组织新产品展销等方面不断完善售前服务体系。除此之外还要更多的了解消费者和竞争对手的情况，权衡各方面的因素制定出适当的促销策略提高产品销售。&lt;/p&gt;&lt;p&gt;全面而完善的售前服务不仅能够提高销量维系经销商与企业之间的合作关系，也能提升品牌在当地的影响力。塑胶地板企业制定完善的服务体系是吸引各经销商加盟的重要因素，因此塑胶地板企业只有完善才能不断提高自己的销量，提高品牌知名度。&lt;/p&gt;','88.00','55.00','52HH','99*55','a:2:{s:7:\"fileurl\";a:2:{i:0;s:48:\"/data/upload/image/20181222/1545454487520856.jpg\";i:1;s:48:\"/data/upload/image/20181222/1545454487135627.jpg\";}s:8:\"filename\";a:2:{i:0;s:5:\"1.jpg\";i:1;s:5:\"2.jpg\";}}');
INSERT INTO `qing_content_product` VALUES('11','12','&lt;p&gt;功能强大，不仅具备现有喷码机的相同功能，更提供多种其它实用功能&lt;/p&gt;&lt;p&gt;机身小巧灵便，价格低廉，调节机体高度极为方便，更加适用于流水线生产作业。&lt;/p&gt;&lt;p&gt;适用行业：如手机显示屏、饮料瓶盖 、食品外包装袋、药盒、塑钢门窗、铝合金、电池、塑料管材、钢板、电路板、芯片、编织袋、鸡蛋、刹车片、手机外壳、纸箱等。&lt;/p&gt;','88.00','55.00','52HH','99*55','a:2:{s:7:\"fileurl\";a:3:{i:0;s:48:\"/data/upload/image/20181222/1545454871547020.jpg\";i:1;s:48:\"/data/upload/image/20181222/1545454871796389.jpg\";i:2;s:48:\"/data/upload/image/20181222/1545454871269637.jpg\";}s:8:\"filename\";a:3:{i:0;s:5:\"1.jpg\";i:1;s:5:\"2.jpg\";i:2;s:5:\"3.jpg\";}}');
INSERT INTO `qing_content_product` VALUES('29','12','&lt;p&gt;DX-905 (快干型有机硅密封胶) 系列是一种可进行快速粘接的有机硅胶粘剂，绝缘性优、粘接性好，防潮、抗震、耐电晕、抗漏电。胶料对金属和大多数塑料的粘接性良好，固化后具有卓越的抗冷热交变性能(-40~200℃)。&lt;/p&gt;','111','222','333','4444','a:2:{s:7:\"fileurl\";a:2:{i:0;s:48:\"/data/upload/image/20181226/1545821597740671.jpg\";i:1;s:48:\"/data/upload/image/20181226/1545821603189073.jpg\";}s:8:\"filename\";a:2:{i:0;s:20:\"1545453800956381.jpg\";i:1;s:22:\"20181206104724_744.jpg\";}}');
INSERT INTO `qing_content_product` VALUES('30','12','&lt;p style=&quot;padding: 0px; margin-top: 0px; margin-bottom: 0px; transition: all 0.2s linear; font-size: 14px; color: rgb(102, 102, 102); font-family: 微软雅黑; white-space: normal; background-color: rgb(255, 255, 255);&quot;&gt;产品概述：CODcr在线自动监测仪将重铬酸钾消解方法与先进的计算机技术结合起来，实现了测定过程的全自动化。可广泛地应用于厂矿企业排污口监测、城市污水处理工厂进出口监测、江河湖泊水质监测和污水治理设施控制装置之中。&lt;/p&gt;&lt;p style=&quot;padding: 0px; margin-top: 0px; margin-bottom: 0px; transition: all 0.2s linear; font-size: 14px; color: rgb(102, 102, 102); font-family: 微软雅黑; white-space: normal; background-color: rgb(255, 255, 255);&quot;&gt;特点：&lt;/p&gt;&lt;p style=&quot;padding: 0px; margin-top: 0px; margin-bottom: 0px; transition: all 0.2s linear; font-size: 14px; color: rgb(102, 102, 102); font-family: 微软雅黑; white-space: normal; background-color: rgb(255, 255, 255);&quot;&gt;·本仪器是国标（GB11914-89）规定方法的自动化装置，与手动分析具有很好的相关性。&lt;/p&gt;&lt;p style=&quot;padding: 0px; margin-top: 0px; margin-bottom: 0px; transition: all 0.2s linear; font-size: 14px; color: rgb(102, 102, 102); font-family: 微软雅黑; white-space: normal; background-color: rgb(255, 255, 255);&quot;&gt;·本仪器已通过中国环境产业协会认证，检测数据具有法定效力。&lt;/p&gt;&lt;p style=&quot;padding: 0px; margin-top: 0px; margin-bottom: 0px; transition: all 0.2s linear; font-size: 14px; color: rgb(102, 102, 102); font-family: 微软雅黑; white-space: normal; background-color: rgb(255, 255, 255);&quot;&gt;·本仪器具有很宽的量程范围，并可在一定范围内实现不同量程之间的自动切换。&lt;/p&gt;&lt;p style=&quot;padding: 0px; margin-top: 0px; margin-bottom: 0px; transition: all 0.2s linear; font-size: 14px; color: rgb(102, 102, 102); font-family: 微软雅黑; white-space: normal; background-color: rgb(255, 255, 255);&quot;&gt;·本仪器具有强的抗氯离子干扰能力，l可直接检测氯离子含量达到10000mg/L的水样。&lt;/p&gt;&lt;p style=&quot;padding: 0px; margin-top: 0px; margin-bottom: 0px; transition: all 0.2s linear; font-size: 14px; color: rgb(102, 102, 102); font-family: 微软雅黑; white-space: normal; background-color: rgb(255, 255, 255);&quot;&gt;·新颖的电热设计，确保高的氧化率和寿命。&lt;/p&gt;&lt;p style=&quot;padding: 0px; margin-top: 0px; margin-bottom: 0px; transition: all 0.2s linear; font-size: 14px; color: rgb(102, 102, 102); font-family: 微软雅黑; white-space: normal; background-color: rgb(255, 255, 255);&quot;&gt;·断电保护设计确保仪器不受损坏和数据记录永不丢失。&lt;/p&gt;&lt;p style=&quot;padding: 0px; margin-top: 0px; margin-bottom: 0px; transition: all 0.2s linear; font-size: 14px; color: rgb(102, 102, 102); font-family: 微软雅黑; white-space: normal; background-color: rgb(255, 255, 255);&quot;&gt;·齐全的接口设计和配套软件，便于仪器与流量计、控制系统和中央监控计算机连接，并可接受遥控指令。&lt;/p&gt;&lt;p style=&quot;padding: 0px; margin-top: 0px; margin-bottom: 0px; transition: all 0.2s linear; font-size: 14px; color: rgb(102, 102, 102); font-family: 微软雅黑; white-space: normal; background-color: rgb(255, 255, 255);&quot;&gt;·故障自诊断智能设计，使仪器管理和维护十分方便。&lt;/p&gt;&lt;p style=&quot;padding: 0px; margin-top: 0px; margin-bottom: 0px; transition: all 0.2s linear; font-size: 14px; color: rgb(102, 102, 102); font-family: 微软雅黑; white-space: normal; background-color: rgb(255, 255, 255);&quot;&gt;·采样方式可设定为定时采样，也可以设定为等比例采样。&lt;/p&gt;&lt;p style=&quot;padding: 0px; margin-top: 0px; margin-bottom: 0px; transition: all 0.2s linear; font-size: 14px; color: rgb(102, 102, 102); font-family: 微软雅黑; white-space: normal; background-color: rgb(255, 255, 255);&quot;&gt;·本仪器具有较强的可扩展性，可最多设置四个采样点的水质分析，方便污水处理的流程控制。产品出厂时配备可在两个采样口采样的功能模块，如果需要测试更多的采样点（最大四个）则需要扩展功能模块。&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;','111','222','333','444','a:2:{s:7:\"fileurl\";a:1:{i:0;s:48:\"/data/upload/image/20181226/1545821628572959.jpg\";}s:8:\"filename\";a:1:{i:0;s:20:\"1545453800956381.jpg\";}}');
INSERT INTO `qing_content_product` VALUES('31','12','&lt;p&gt;DX-905 (快干型有机硅密封胶) 系列是一种可进行快速粘接的有机硅胶粘剂，绝缘性优、粘接性好，防潮、抗震、耐电晕、抗漏电。胶料对金属和大多数塑料的粘接性良好，固化后具有卓越的抗冷热交变性能(-40~200℃)。&lt;/p&gt;','222','333','444','555','a:2:{s:7:\"fileurl\";a:1:{i:0;s:48:\"/data/upload/image/20181226/1545821693526506.jpg\";}s:8:\"filename\";a:1:{i:0;s:18:\"20181224181407.jpg\";}}');
INSERT INTO `qing_content_product` VALUES('32','12','&lt;p&gt;DX-905 (快干型有机硅密封胶) 系列是一种可进行快速粘接的有机硅胶粘剂，绝缘性优、粘接性好，防潮、抗震、耐电晕、抗漏电。胶料对金属和大多数塑料的粘接性良好，固化后具有卓越的抗冷热交变性能(-40~200℃)。&lt;/p&gt;','11','22','33','444','a:2:{s:7:\"fileurl\";a:1:{i:0;s:48:\"/data/upload/image/20181226/1545821749736985.jpg\";}s:8:\"filename\";a:1:{i:0;s:20:\"1545453800956381.jpg\";}}');

DROP TABLE IF EXISTS `qing_diy_banner`;
CREATE TABLE `qing_diy_banner` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `weizhi` varchar(255) NOT NULL,
  `tupian` varchar(255) NOT NULL,
  `lianjie` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `qing_diy_banner` VALUES('1','电脑版','/data/upload/image/20181222/1545448892158399.jpg','');
INSERT INTO `qing_diy_banner` VALUES('2','电脑版','/data/upload/image/20181222/1545448901126380.jpg','');
INSERT INTO `qing_diy_banner` VALUES('3','手机版','/data/upload/image/20181222/1545448959532001.jpg','');
INSERT INTO `qing_diy_banner` VALUES('4','手机版','/data/upload/image/20181222/1545448968746257.jpg','');

DROP TABLE IF EXISTS `qing_diy_flink`;
CREATE TABLE `qing_diy_flink` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `sitename` varchar(255) NOT NULL,
  `siteurl` varchar(255) NOT NULL,
  `paixu` mediumint(8) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `qing_diy_flink` VALUES('1','西部数码代理商','http://www.seozhuji.cn/','3');
INSERT INTO `qing_diy_flink` VALUES('2','聚搜营销','http://www.jusoucn.com/','1');

DROP TABLE IF EXISTS `qing_form_comment`;
CREATE TABLE `qing_form_comment` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `cid` mediumint(8) NOT NULL,
  `userid` mediumint(8) NOT NULL,
  `username` char(20) NOT NULL,
  `listorder` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(2) unsigned NOT NULL DEFAULT '1',
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  `ip` char(20) DEFAULT NULL,
  `pinglunneirong` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `listorder` (`listorder`),
  KEY `status` (`status`),
  KEY `time` (`time`),
  KEY `userid` (`userid`),
  KEY `cid` (`cid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `qing_form_gestbook`;
CREATE TABLE `qing_form_gestbook` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `cid` mediumint(8) NOT NULL,
  `userid` mediumint(8) NOT NULL,
  `username` char(20) NOT NULL,
  `listorder` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(2) unsigned NOT NULL DEFAULT '1',
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  `ip` char(20) DEFAULT NULL,
  `xingming` varchar(255) NOT NULL,
  `dianhua` varchar(255) NOT NULL,
  `youxiang` varchar(255) NOT NULL,
  `liuyanneirong` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `listorder` (`listorder`),
  KEY `status` (`status`),
  KEY `time` (`time`),
  KEY `userid` (`userid`),
  KEY `cid` (`cid`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `qing_keylink`;
CREATE TABLE `qing_keylink` (
  `id` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `link` varchar(100) NOT NULL,
  `weight` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `qing_member`;
CREATE TABLE `qing_member` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `username` char(20) NOT NULL DEFAULT '',
  `password` char(32) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL,
  `avatar` varchar(100) NOT NULL DEFAULT '',
  `modelid` smallint(5) NOT NULL,
  `regdate` int(10) unsigned NOT NULL DEFAULT '0',
  `regip` varchar(50) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `qing_member_connect`;
CREATE TABLE `qing_member_connect` (
  `uid` mediumint(9) NOT NULL,
  `openid` varchar(32) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `qing_member_geren`;
CREATE TABLE `qing_member_geren` (
  `id` mediumint(8) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `qing_model`;
CREATE TABLE `qing_model` (
  `modelid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `typeid` tinyint(3) NOT NULL,
  `modelname` char(30) NOT NULL,
  `tablename` char(20) NOT NULL,
  `listtpl` varchar(30) NOT NULL,
  `showtpl` varchar(30) NOT NULL,
  `joinid` smallint(5) DEFAULT NULL,
  `setting` text,
  PRIMARY KEY (`modelid`),
  KEY `typeid` (`typeid`),
  KEY `joinid` (`joinid`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

INSERT INTO `qing_model` VALUES('1','1','文章模型','content_news','list_news.html','show_news.html','0','a:1:{s:7:\"default\";a:6:{s:5:\"title\";a:2:{s:4:\"name\";s:6:\"标题\";s:4:\"show\";s:1:\"1\";}s:8:\"keywords\";a:2:{s:4:\"name\";s:9:\"关键字\";s:4:\"show\";s:1:\"1\";}s:5:\"thumb\";a:2:{s:4:\"name\";s:9:\"缩略图\";s:4:\"show\";s:1:\"1\";}s:11:\"description\";a:2:{s:4:\"name\";s:6:\"描述\";s:4:\"show\";s:1:\"1\";}s:4:\"time\";a:2:{s:4:\"name\";s:12:\"发布时间\";s:4:\"show\";s:1:\"1\";}s:4:\"hits\";a:2:{s:4:\"name\";s:9:\"阅读数\";s:4:\"show\";s:1:\"1\";}}}');
INSERT INTO `qing_model` VALUES('2','1','产品模型','content_product','list_product.html','show_product.html','0','a:1:{s:7:\"default\";a:6:{s:5:\"title\";a:2:{s:4:\"name\";s:6:\"标题\";s:4:\"show\";s:1:\"1\";}s:8:\"keywords\";a:2:{s:4:\"name\";s:9:\"关键字\";s:4:\"show\";s:1:\"1\";}s:5:\"thumb\";a:2:{s:4:\"name\";s:9:\"缩略图\";s:4:\"show\";s:1:\"1\";}s:11:\"description\";a:2:{s:4:\"name\";s:6:\"描述\";s:4:\"show\";s:1:\"1\";}s:4:\"time\";a:2:{s:4:\"name\";s:12:\"发布时间\";s:4:\"show\";s:1:\"1\";}s:4:\"hits\";a:2:{s:4:\"name\";s:9:\"阅读数\";s:4:\"show\";s:1:\"1\";}}}');
INSERT INTO `qing_model` VALUES('3','3','在线留言','form_gestbook','list_gestbook.html','form.html','0','a:1:{s:4:\"form\";a:11:{s:4:\"post\";s:1:\"0\";s:3:\"num\";s:1:\"0\";s:4:\"time\";s:0:\"\";s:5:\"check\";s:1:\"0\";s:4:\"code\";s:1:\"0\";s:6:\"member\";s:1:\"0\";s:5:\"email\";s:1:\"1\";s:11:\"smtpemailto\";s:18:\"luokai@jusoucn.com\";s:11:\"mailsubject\";s:15:\"网站新留言\";s:4:\"show\";a:4:{i:0;s:8:\"youxiang\";i:1;s:8:\"xingming\";i:2;s:7:\"dianhua\";i:3;s:13:\"liuyanneirong\";}s:10:\"membershow\";a:4:{i:0;s:8:\"youxiang\";i:1;s:8:\"xingming\";i:2;s:7:\"dianhua\";i:3;s:13:\"liuyanneirong\";}}}');
INSERT INTO `qing_model` VALUES('4','3','文章评论','form_comment','list_comment.html','form.html','1','a:2:{s:4:\"form\";a:8:{s:4:\"post\";s:1:\"0\";s:3:\"num\";s:1:\"0\";s:4:\"time\";s:0:\"\";s:5:\"check\";s:1:\"0\";s:4:\"code\";s:1:\"0\";s:6:\"member\";s:1:\"0\";s:4:\"show\";a:1:{i:0;s:14:\"pinglunneirong\";}s:10:\"membershow\";a:1:{i:0;s:14:\"pinglunneirong\";}}s:7:\"disable\";s:1:\"1\";}');
INSERT INTO `qing_model` VALUES('5','2','个人','member_geren','list_geren.html','show_geren.html','0','');
INSERT INTO `qing_model` VALUES('6','4','首页banner','diy_banner','list_banner.html','show_banner.html','0','a:1:{s:4:\"form\";a:1:{s:4:\"show\";a:3:{i:0;s:6:\"weizhi\";i:1;s:6:\"tupian\";i:2;s:7:\"lianjie\";}}}');
INSERT INTO `qing_model` VALUES('7','4','友情链接','diy_flink','list_flink.html','show_flink.html','0','a:1:{s:4:\"form\";a:1:{s:4:\"show\";a:3:{i:0;s:8:\"sitename\";i:1;s:7:\"siteurl\";i:2;s:5:\"paixu\";}}}');

DROP TABLE IF EXISTS `qing_model_field`;
CREATE TABLE `qing_model_field` (
  `fieldid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `modelid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `field` varchar(20) NOT NULL,
  `name` varchar(30) NOT NULL,
  `isshow` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `tips` text NOT NULL,
  `pattern` varchar(255) NOT NULL,
  `errortips` varchar(255) NOT NULL,
  `formtype` varchar(20) NOT NULL,
  `setting` mediumtext NOT NULL,
  `listorder` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `disabled` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`fieldid`),
  KEY `modelid` (`modelid`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

INSERT INTO `qing_model_field` VALUES('1','1','content','内容','1','','','','editor','a:4:{s:7:\"toolbar\";s:1:\"1\";s:5:\"width\";s:3:\"700\";s:6:\"height\";s:3:\"450\";s:12:\"defaultvalue\";s:0:\"\";}','0','0');
INSERT INTO `qing_model_field` VALUES('2','2','content','内容','1','','','','editor','a:4:{s:7:\"toolbar\";s:1:\"1\";s:5:\"width\";s:3:\"700\";s:6:\"height\";s:3:\"450\";s:12:\"defaultvalue\";s:0:\"\";}','0','0');
INSERT INTO `qing_model_field` VALUES('18','3','youxiang','邮箱','1','','','','input','a:2:{s:4:\"size\";s:3:\"380\";s:12:\"defaultvalue\";s:0:\"\";}','0','0');
INSERT INTO `qing_model_field` VALUES('16','3','xingming','姓名','1','','1','','input','a:2:{s:4:\"size\";s:3:\"380\";s:12:\"defaultvalue\";s:0:\"\";}','0','0');
INSERT INTO `qing_model_field` VALUES('17','3','dianhua','电话','1','','1','','input','a:2:{s:4:\"size\";s:3:\"380\";s:12:\"defaultvalue\";s:0:\"\";}','0','0');
INSERT INTO `qing_model_field` VALUES('6','4','pinglunneirong','评论内容','1','','1','评论内容不能为空','textarea','a:3:{s:5:\"width\";s:3:\"400\";s:6:\"height\";s:2:\"90\";s:12:\"defaultvalue\";s:0:\"\";}','0','0');
INSERT INTO `qing_model_field` VALUES('7','6','weizhi','位置','1','','1','','radio','a:2:{s:7:\"content\";s:40:\"电脑版|电脑版\r\n手机版|手机版\";s:12:\"defaultvalue\";s:0:\"\";}','0','0');
INSERT INTO `qing_model_field` VALUES('8','6','tupian','图片','1','','1','','file','a:3:{s:4:\"type\";s:20:\"jpg,jpeg,bmp,gif,png\";s:7:\"preview\";s:1:\"1\";s:4:\"size\";s:1:\"2\";}','0','0');
INSERT INTO `qing_model_field` VALUES('9','6','lianjie','链接','1','格式：http://www.baidu.com，没有则留空','','','input','a:2:{s:4:\"size\";s:3:\"380\";s:12:\"defaultvalue\";s:0:\"\";}','0','0');
INSERT INTO `qing_model_field` VALUES('10','2','yuanjia','原价','1','','1','','input','a:2:{s:4:\"size\";s:3:\"380\";s:12:\"defaultvalue\";s:0:\"\";}','4','0');
INSERT INTO `qing_model_field` VALUES('11','2','xianjia','现价','1','','1','','input','a:2:{s:4:\"size\";s:3:\"380\";s:12:\"defaultvalue\";s:0:\"\";}','3','0');
INSERT INTO `qing_model_field` VALUES('12','2','xinghao','型号','1','','1','','input','a:2:{s:4:\"size\";s:3:\"380\";s:12:\"defaultvalue\";s:0:\"\";}','2','0');
INSERT INTO `qing_model_field` VALUES('13','2','guige','规格','1','','1','','input','a:2:{s:4:\"size\";s:3:\"380\";s:12:\"defaultvalue\";s:0:\"\";}','1','0');
INSERT INTO `qing_model_field` VALUES('14','2','zutu','组图','1','','1','','files','a:3:{s:4:\"type\";s:20:\"jpg,jpeg,bmp,gif,png\";s:7:\"preview\";s:1:\"1\";s:4:\"size\";s:1:\"2\";}','5','0');
INSERT INTO `qing_model_field` VALUES('15','0','catenname','英文名称','1','','','','input','a:2:{s:4:\"size\";s:3:\"380\";s:12:\"defaultvalue\";s:0:\"\";}','0','0');
INSERT INTO `qing_model_field` VALUES('19','3','liuyanneirong','留言内容','1','','1','','textarea','a:3:{s:5:\"width\";s:3:\"500\";s:6:\"height\";s:2:\"46\";s:12:\"defaultvalue\";s:0:\"\";}','0','0');
INSERT INTO `qing_model_field` VALUES('20','7','sitename','网站名称','1','','1','','input','a:2:{s:4:\"size\";s:3:\"380\";s:12:\"defaultvalue\";s:0:\"\";}','3','0');
INSERT INTO `qing_model_field` VALUES('21','7','siteurl','网址','1','格式：http://www.baidu.com','1','','input','a:2:{s:4:\"size\";s:3:\"380\";s:12:\"defaultvalue\";s:0:\"\";}','2','0');
INSERT INTO `qing_model_field` VALUES('22','7','paixu','排序','1','数值越小排序越靠前','/^[0-9-]+$/','','input','a:2:{s:4:\"size\";s:3:\"380\";s:12:\"defaultvalue\";s:1:\"0\";}','1','0');

DROP TABLE IF EXISTS `qing_weixinmenu`;
CREATE TABLE `qing_weixinmenu` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `child` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `childids` varchar(255) NOT NULL,
  `name` varchar(30) NOT NULL,
  `url` varchar(255) NOT NULL DEFAULT '',
  `listorder` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `listorder` (`listorder`,`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `qing_weixinmenu` VALUES('1','0','0','','测试','http://test.juqingcms.com','0');


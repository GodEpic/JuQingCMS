<style type="text/css">
.fottxt {
	padding-top: 30px;height:122px;
	padding-left: 128px;
	line-height: 30px;
	color: #999;
	background: url(<?php $this->block(4);?>) no-repeat left 30px;
	background-size:92px 92px;
	border-top: 1px solid #484848;
}
</style>
<div class="clear"> </div>
<div class="page_top"><span id="pageTop"><a >[向上]</a></span> </div>
<div class="footwrap">
  <div class="footer container">
    <div class="fotnav">
      <a class="nobg" href="<?php echo $site_url; ?>">网站首页</a>
      <?php $return = $this->_category(" ");  if (is_array($return))  foreach ($return as $key=>$qing) { $allchildids = @explode(',', $qing['allchildids']);    $current = in_array($catid, $allchildids);?>
      <a href="<?php echo $qing[url]; ?>"  rel='dropmenu3'><?php echo $qing[catname]; ?></a>
      <?php } ?>
    </div>
    <div class="fottxt"> Copyright &copy; <?php $this->block(17);?> 版权所有 <br />
      400电话：<?php $this->block(5);?> 手机：<?php $this->block(6);?> 传真：<?php $this->block(7);?> 邮箱：<?php $this->block(11);?><br />
      地址：<?php $this->block(12);?></div>
    <dl class="fotphone">
      <dt>全国服务热线</dt>
      <dd><?php $this->block(5);?></dd>
    </dl>
  </div>
</div>
<div class="online-qq" style="right:3px">
  <dl class="qq_content">
    <dt class="dt">在线客服</dt>
    <dd class="qq">
      <p><a href="tencent://message/?uin=<?php $this->block(8);?>&Site=&Menu=yes" title="在线咨询">在线咨询</a></p>
      <p><a href="tencent://message/?uin=<?php $this->block(9);?>&Site=&Menu=yes" title="在线咨询">在线咨询</a></p>
      <p><a href="tencent://message/?uin=<?php $this->block(10);?>&Site=&Menu=yes" title="在线咨询">在线咨询</a></p>
    </dd>
    <dd class="tel"> 咨询电话：<br />
      <strong><?php $this->block(5);?></strong> </dd>
    <dd class="tel"> <img src="<?php $this->block(4);?>" alt="二维码" />
      <p>关注微信</p>
    </dd>
  </dl>
  <div class="footqq"></div>
</div>
<script src="<?php echo $site_template; ?>style/js/common.js" type="text/javascript"></script>
<script>
function checksearch(the){
  if ($.trim(the.kw.value)=='')
  {   alert('请输入关键字');
    the.kw.focus();
    the.kw.value='';
    return false
  }
  if ($.trim(the.kw.value)=='请输入关键字')
  {   alert('请输入关键字');
    the.kw.focus();
    the.kw.value='';
    return false
  } 
}
$("#pageTop").click(function(){
	$('body,html').animate({scrollTop:0},500);
	return false;
});
</script>
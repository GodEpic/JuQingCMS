<?php return array (
  'file_explan' => 
  array (
    'template|jiancai001|' => 
    array (
      'style' => '',
      'config.php' => '',
      'footer.html' => '测试',
      'form.html' => '',
      'header.html' => '',
      'index.html' => '',
      'left.html' => '',
      'list_news.html' => '',
      'list_news_pic.html' => '',
      'list_product.html' => '',
      'page.html' => '',
      'search.html' => '',
      'show_news.html' => '',
      'show_product.html' => '',
      'top.html' => '',
      'weizhi.html' => '',
    ),
  ),
);?>
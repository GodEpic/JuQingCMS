<?php include $this->admin_tpl('header');?>
 
 <div class="position">当前位置：会员列表</div>

<div class="subnav">
	<div class="content-menu">
		<a href="../member/index.php?c=register"   class="add" target="_blank"><em>注册会员</em></a>
	</div>
	<div class="bk10"></div>
		<form action="" method="post" name="myform" id="myform">
		<input name="status" id="list_form" type="hidden" value="">
		<table width="100%"  class="am-table am-table-hover">
		<thead class="table-thead">
		<tr>
			<th width="25" align="left"><input name="deletec" id="deletec" type="checkbox" onclick="setC()"></th>
			<th width="30" align="left">ID </th>
			<th align="left">用户名</th>
			<th width="100" align="left">会员模型</th>
			<th width="150" align="left">注册时间</th>
			<th width="120" align="left">注册IP</th>
			<th  width="150" align="left">操作</th>
		</tr>
		</thead>
		<tbody >
		<?php if (is_array($list)) {foreach ($list as $t) {  ?>
		<tr >
			<td ><input name="member[]" value="<?php echo $t['id']; ?>"  type="checkbox" class="deletec"></td>
			<td align="left"><?php echo $t['id']; ?></td>
			<td align="left"><?php if (!$t['status']) { ?><font color="#FF0000">[未审]</font><?php } ?>
			<a href="<?php echo url('member/edit',array('id'=>$t['id'])); ?>"><?php echo $t['username']; ?></a></td>
			<td align="left"><a href="<?php echo url('member/index', array('modelid'=>$t['modelid'])); ?>"><?php echo $member_model[$t['modelid']]['modelname']; ?></a></td>
			<td align="left"><?php echo date('Y-m-d H:i:s', $t['regdate']); ?></td>
			<td align="left"><?php echo $t['regip']; ?></td>
			<td align="left"><a href="<?php echo url('member/edit',array('id'=>$t['id'])); ?>">详细</a> | 
			<a href="javascript:confirmurl('<?php echo url('member/del/',array('modelid'=>$t['modelid'],'id'=>$t['id']));?>','确定删除会员 『 <?php echo $t['username']; ?> 』吗？ ')" ><span class="am-icon-trash"></span>删除</a> 
			</td>
		</tr>
		<?php } } ?>
 		</tbody>
		</table>

		<div class="border-top am-padding">
			<div class="am-u-sm-6 am-padding-left-0">

				<input type="button"  class="am-btn am-btn-warning am-radius am-text-sm" value="删除" name="order" onClick="confirm_delete()">
				<input type="submit" class="am-btn am-btn-warning am-radius am-text-sm" value="设为审核" name="submit_status_1" onClick="$('#list_form').val('1')">
				<input type="submit" class="am-btn am-btn-warning am-radius am-text-sm" value="设未审核" name="submit_status_0" onClick="$('#list_form').val('2')">


			</div>
			<div class="am-u-sm-6 pagelist"><?php echo  $pagelist; ?></div>
			<div class="clear"></div>
		</div>

		</form>
	</div>

</body>
</html>
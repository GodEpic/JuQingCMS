<div id="header">
  <div class="hd_cont container">
    <dl class="hd_logo">
      <dt class="fl"><a href="<?php echo $site_url; ?>"> <img src="<?php $this->block(1);?>" alt="<?php echo $site_name; ?>" width="227" height="56"></a></dt>
      <dd class="fl">
        <?php $this->block(3);?>
      </dd>
    </dl>
    <dl class="dh_phone fr">
      <dt>全国服务咨询热线</dt>
      <dd><?php $this->block(5);?></dd>
    </dl>
  </div>
  <div id="nav">
    <div id="navMenu">
      <ul>
        <li <?php if ($index) { ?>class='home'<?php } ?>><a href="<?php echo $site_url; ?>">网站首页</a></li>
        <?php $return = $this->_category(" ");  if (is_array($return))  foreach ($return as $key=>$qing) { $allchildids = @explode(',', $qing['allchildids']);    $current = in_array($catid, $allchildids);?>
        <li <?php if ($current) { ?>class='home'<?php } ?>><a href="<?php echo $qing[url]; ?>"  rel='dropmenu'><?php echo $qing[catname]; ?></a></li>
        <?php } ?>
      </ul>
    </div>
  </div>
</div>
<?php if ($index) { ?>
<div id="banner">
  <ul class="ulBanner">
    <?php $return = $this->_listdata("table=diy_banner weizhi=电脑版"); extract($return); if (is_array($return))  foreach ($return as $key=>$qing) {  if ($qing[lianjie]) { ?>
    <a href="<?php echo $qing[lianjie]; ?>" target="_blank"><li class="banner" style="background: url(<?php echo $qing[tupian]; ?>) no-repeat center scroll;"> </li></a>
    <?php } else { ?>
    <li class="banner" style="background: url(<?php echo $qing[tupian]; ?>) no-repeat center scroll;"> </li>
    <?php }  } ?>
  </ul>
  <ul class="ulBannerNav">
    <?php $return = $this->_listdata("table=diy_banner weizhi=电脑版"); extract($return); if (is_array($return))  foreach ($return as $key=>$qing) { ?>
    <li <?php if ($key==0) { ?>class="on"<?php } ?>></li>
    <?php } ?>
  </ul>
</div>
<script type="text/javascript">
$(document).ready(function () {
	$("#banner").Slide({
		effect: "fade",
		speed: "normal",
		timer: 3500,
		autoPlay: true,
		defIndex: 0,
		claNav: "ulBannerNav",
		claCon: "ulBanner",
		steps: 1
	});
});
</script>
<?php } else {  if ($cats[$topid][image]) { ?>
<div class="MB10" style="background:url(<?php echo $cats[$topid][image]; ?>) center top no-repeat; width:100%; height:300px;"></div>
<?php } else { ?>
<div class="MB10" style="background:url(<?php $this->block(14);?>) center top no-repeat; width:100%; height:300px;"></div>
<?php }  } ?>
<div class="clear"></div>
<?php
define('JUQINGCMS_RELEASE', '1.0');
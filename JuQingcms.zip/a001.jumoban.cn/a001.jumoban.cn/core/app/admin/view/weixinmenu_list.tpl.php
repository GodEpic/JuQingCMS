<?php include $this->admin_tpl('header','admin');?>

<div class="subnav">
		<form action="" method="get" name="myform">
	<div class="content-menu">
		<a href="?c=weixinmenu&a=add"  class="add"><em>添加菜单</em></a>
		<input type="submit" class="button add" value="编辑菜单后 点击此处提交到微信才可生效（一般24小时生效）" name="submit">
	</div>
	<div class="bk10"></div>
		<input type="hidden" name="c" value="weixinmenu">
		<input type="hidden" name="a" value="post">
		<table width="100%"  class="am-table am-table-hover am-table am-table-hover-row">
		<thead class="am-table am-table-hover-thead s-table-thead">
		<tr>
			<th width="20" align="left">ID </th>
			<th width="200" align="left">连接名称</th>
			<th align="left">连接地址</th>
			<th width="180" align="left">操作</th>
		</tr>
		</thead>
		<tbody >
		<?php echo $menu ;?> 
 		</tbody>
		</table>
		</form>
</div> 
</body>
</html>
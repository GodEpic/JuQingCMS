<?php include $this->admin_tpl('header','admin');?>
 
<div class="subnav">
	<div class="content-menu">
		<a href="?c=weixinmenu"  class="on"><em>微信菜单</em></a>
		<a href="?c=weixinmenu&a=add"  class="add"><em>添加菜单</em></a>
	</div>

	<div class="bk10"></div>
		<form method="post" action="" id="myform" name="myform">
		<input type="hidden" value="<?php echo $id; ?>" name="id">
					
					<table width="100%" class="table_form ">
					<tbody>
					<tr>
						<th width="120"><font color="red">*</font> 上级菜单：</th>
						<td>
						<select class="select"  id="parentid" name="data[parentid]">
						<option value="0">作为顶级菜单</option>
						<?php echo $menu; ?>
						</select>
						</td>
					</tr>
					<tr>
						<th><font color="red">*</font> 菜单名称：</th>
						<td><input type="text" class="input-text" size="30" value="<?php echo $data['name']; ?>" name="data[name]"></td>
					</tr>
					<tr>
						<th><font color="red">*</font> 连接地址：</th>
						<td><input type="text" class="input-text" size="60" value="<?php echo $data['url']; ?>" name="data[url]"></td>
					</tr>
					<tr>
						<th></th>
						<td><input type="submit" class="button" value="提交" name="submit"></td>
					</tr>

					</tbody>
					</table>
					




					<div class="bk15"></div>
		</form>
</div>
</body>
</html>
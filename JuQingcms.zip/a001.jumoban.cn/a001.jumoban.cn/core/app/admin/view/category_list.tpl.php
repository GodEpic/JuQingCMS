<?php include $this->admin_tpl('header');?>
 
<div class="position">当前位置：栏目管理</div>
<div class="subnav">
	<div class="content-menu">
	<div class="left">
		<a href="<?php echo url('category'); ?>"  class="on"><em>全部栏目</em></a>
		<a href="<?php echo url('weixinmenu'); ?>"  class="on"><em>微信菜单</em></a>
		<?php if($this->menu('category-add')) { ;?>
		<a href="<?php echo url('category/add'); ?>"  class="add"><em>添加栏目</em></a>
    	<?php } ?>
    </div>
	<div class="right"> 
     </div>
	</div>
	<div class="bk10"></div>
		<form action="" method="post" name="myform">
		<table width="100%"  class="am-table am-table-hover">
		<thead class="table-thead">
		<tr>
			<th width="40" align="left">排序</th>
			<th width="80" align="left">栏目ID </th>
			<th align="left">栏目名称</th>
			<th align="left">类型</th>
			<th align="left">内容</th>
			<th align="left">显示</th>
			<th width="220" align="left">操作</th>
		</tr>
		</thead>
		<tbody >
		<?php echo $categorys ;?> 
		</tbody>
		</table>
			<input type="submit" class="am-btn am-btn-warning am-radius am-text-sm" value="排序" name="submit">

		
		</form>
</div>
</body>
</html>